use num::ToPrimitive;
use std::fmt::{Display, Write};
use std::str::FromStr;

use crate::DefaultIdx;

#[derive(Debug)]
pub enum FixedPointNumberError {
    OutOfRange { value: f64, range: (f64, f64) },
    UnknownFailure { msg: String },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct FixedPointNumber {
    inner: u16,
}

impl FixedPointNumber {
    const LOWER_LIMIT: f64 = -1.0;
    const UPPER_LIMIT: f64 = 8.0;
    const DELTA: f64 = (Self::UPPER_LIMIT - Self::LOWER_LIMIT) / 65535.0;
    const INV_DELTA: f64 = 65535.0 / (Self::UPPER_LIMIT - Self::LOWER_LIMIT);

    pub fn try_from<T: ToPrimitive + Display + Clone>(
        value: T,
    ) -> Result<Self, FixedPointNumberError> {
        let Some(value_f64) = value.clone().to_f64() else {
            return Err(FixedPointNumberError::UnknownFailure {
                msg: format!("Failed to convert {} to f64", value),
            });
        };

        if !(Self::LOWER_LIMIT <= value_f64 && value_f64 < Self::UPPER_LIMIT) {
            return Err(FixedPointNumberError::OutOfRange {
                value: value_f64,
                range: (Self::LOWER_LIMIT, Self::UPPER_LIMIT),
            });
        }

        let inner_f64 = (value_f64 - Self::LOWER_LIMIT) * Self::INV_DELTA;
        let Some(inner) = inner_f64.clamp(0.0, 65536.0).round().to_u16() else {
            // 数値の変換を順を追って説明し、どこで問題が生じたのかを説明する
            // f64 -> inner_f64 -> inner -> u16までの流れ等
            let mut msg = format!("Failed to convert {} to FixedPointNumber\n", value);
            writeln!(msg, "    input value: {}\n", value).unwrap();
            writeln!(msg, "    input converted to f64: {}\n", value_f64).unwrap();
            writeln!(
                msg,
                "    then internal positional number computed: pos = {} = ({} - {}) / δ\n",
                inner_f64,
                value_f64,
                Self::LOWER_LIMIT
            )
            .unwrap();
            writeln!(
                msg,
                "        where δ = ({} - {}) / 65535.0\n",
                Self::UPPER_LIMIT,
                Self::LOWER_LIMIT
            )
            .unwrap();
            writeln!(
                msg,
                "    pos is clamped to 0..65536: {}\n",
                inner_f64.clamp(0.0, 65536.0)
            )
            .unwrap();
            writeln!(
                msg,
                "    finally pos is rounded to u16: {} <- Error!",
                inner_f64.clamp(0.0, 65536.0).round()
            )
            .unwrap();
            return Err(FixedPointNumberError::UnknownFailure { msg });
        };

        Ok(Self { inner })
    }

    pub fn to_f64(&self) -> f64 {
        Self::LOWER_LIMIT + (self.inner as f64) * Self::DELTA
    }
}

impl Display for FixedPointNumber {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{:.17}", self.to_f64())
    }
}

#[derive(Debug)]
pub struct SelfLoopError;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BondPair {
    pub small: DefaultIdx,
    pub big: DefaultIdx,
}

impl BondPair {
    pub fn new(head: DefaultIdx, tail: DefaultIdx) -> Result<Self, SelfLoopError> {
        if head == tail {
            return Err(SelfLoopError);
        }
        let (small, big) = if head < tail {
            (head, tail)
        } else {
            (tail, head)
        };
        Ok(Self { small, big })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Bond {
    pub small: DefaultIdx,
    pub big: DefaultIdx,
    pub order: u8,
}

impl Bond {
    pub fn new(head: DefaultIdx, tail: DefaultIdx, order: u8) -> Result<Self, SelfLoopError> {
        if head == tail {
            return Err(SelfLoopError);
        }

        let (small, big) = if head < tail {
            (head, tail)
        } else {
            (tail, head)
        };
        Ok(Self { small, big, order })
    }
}

#[derive(Debug)]
pub enum IllegalCharacterError {
    NonAscii {
        given: String,
        chars: Vec<char>,
    },
    IllegalCharacter {
        given: String,
        chars: Vec<char>,
        illegals: Vec<char>,
    },
}

impl Display for IllegalCharacterError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IllegalCharacterError::NonAscii { given, chars } => {
                writeln!(f, "Non-ascii characters detected.")?;
                writeln!(f, "    given name: {}", given)?;
                writeln!(f, "    non-ascii : {:?}", chars)
            }
            IllegalCharacterError::IllegalCharacter {
                given,
                chars,
                illegals,
            } => {
                writeln!(f, "Illegal characters detected. ")?;
                writeln!(f, "    given name: {}", given)?;
                writeln!(f, "    detected chars: {:?}", chars)?;
                writeln!(f, "    these chars are prohibited: {:?}", illegals)
            }
        }
    }
}

pub fn detect_ssv_unsafe_chars(s: &str) -> Result<(), IllegalCharacterError> {
    // to avoid confusion in Space Separated File parsing,
    // refuse any control character, delimiter, etc.
    if !s.is_ascii() {
        return Err(IllegalCharacterError::NonAscii {
            given: s.to_string(),
            chars: s.chars().filter(|c| !c.is_ascii()).collect(),
        });
    }

    let illegals = [
        '\n', '\r', ',', ':', '\t', '"', '\'', '=', '+', '-', '*', '@', ';', '#', '|', '$', ' ',
        '.',
    ];
    let mut found_illegals = Vec::<char>::new();
    for ch in illegals {
        if s.contains(ch) {
            found_illegals.push(ch);
        }
    }
    if !found_illegals.is_empty() {
        return Err(IllegalCharacterError::IllegalCharacter {
            given: s.to_string(),
            chars: s.chars().collect(),
            illegals: found_illegals,
        });
    }

    Ok(())
}

#[derive(Debug, Clone, PartialEq, Copy)]
pub enum AtomProperty {
    Backbone,
    BackboneTerminal,
    NotBackbone,
    Unset,
}

impl Display for AtomProperty {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            AtomProperty::Backbone => write!(f, "Backbone"),
            AtomProperty::BackboneTerminal => write!(f, "BackboneTerminal"),
            AtomProperty::NotBackbone => write!(f, "NotBackbone"),
            AtomProperty::Unset => write!(f, "Unset"),
        }
    }
}

impl FromStr for AtomProperty {
    type Err = ();

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "Backbone" => Ok(AtomProperty::Backbone),
            "BackboneTerminal" => Ok(AtomProperty::BackboneTerminal),
            "NotBackbone" => Ok(AtomProperty::NotBackbone),
            "Unset" => Ok(AtomProperty::Unset),
            _ => Err(()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use num::rational::Ratio;
    use num::traits::ToPrimitive;
    use rand::Rng;

    // --- FixedPointNumber Tests ---

    #[test]
    fn test_fixed_point_from_valid_f64() {
        let v = 1.23;
        let fp = FixedPointNumber::try_from(v).unwrap();
        assert!((fp.to_f64() - v).abs() < 1e-4);
    }

    #[test]
    fn test_fixed_point_from_valid_rational() {
        let v = Ratio::new(5, 2); // 2.5
        let fp = FixedPointNumber::try_from(v.clone()).unwrap();
        assert!((fp.to_f64() - v.to_f64().unwrap()).abs() < 1e-4);
    }

    #[test]
    fn test_fixed_point_from_out_of_range() {
        let too_large = 10.0;
        let too_small = -2.0;
        assert!(matches!(
            FixedPointNumber::try_from(too_large),
            Err(FixedPointNumberError::OutOfRange { .. })
        ));
        assert!(matches!(
            FixedPointNumber::try_from(too_small),
            Err(FixedPointNumberError::OutOfRange { .. })
        ));
    }

    // --- detect_csv_unsafe_chars Tests ---

    #[test]
    fn test_detect_csv_unsafe_chars_safe() {
        assert!(detect_ssv_unsafe_chars("AlphaNumeric_123").is_ok());
    }

    #[test]
    fn test_detect_csv_unsafe_chars_non_ascii() {
        let err = detect_ssv_unsafe_chars("こんにちは").unwrap_err();
        match err {
            IllegalCharacterError::NonAscii { .. } => {}
            _ => panic!("Expected NonAscii error"),
        }
    }

    #[test]
    fn test_detect_csv_unsafe_chars_illegals() {
        let err = detect_ssv_unsafe_chars("bad,string").unwrap_err();
        match err {
            IllegalCharacterError::IllegalCharacter { illegals, .. } => {
                assert!(illegals.contains(&','));
            }
            _ => panic!("Expected IllegalCharacter error"),
        }
    }

    // --- Fuzz Test for FixedPointNumber::try_from(f64) ---

    #[test]
    fn fuzz_fixed_point_from_f64() {
        let mut rng = rand::rng();
        let near_upper = FixedPointNumber::try_from(8.0 - 1e-4).unwrap();
        assert!(near_upper.to_f64() - 8.0 < 1e-4);

        let near_lower = FixedPointNumber::try_from(-1.0).unwrap();
        assert!(near_lower.to_f64() + 1.0 < 1e-4);

        assert!(FixedPointNumber::try_from(8.0 + 1e-4).is_err());
        assert!(FixedPointNumber::try_from(-1.0 - 1e-4).is_err());

        for _ in 0..1000 {
            let val: f64 =
                rng.random_range(FixedPointNumber::LOWER_LIMIT..FixedPointNumber::UPPER_LIMIT);
            let fixed = FixedPointNumber::try_from(val).unwrap();
            assert!(val - fixed.to_f64() < 1e-4);
        }
    }

    #[test]
    fn test_fixed_point_repeated_text_conversion() {
        let mut rng = rand::rng();
        for _ in 0..1000 {
            let val: f64 =
                rng.random_range(FixedPointNumber::LOWER_LIMIT..FixedPointNumber::UPPER_LIMIT);
            let fixed_1 = FixedPointNumber::try_from(val).unwrap();
            let text_1 = format!("{}", fixed_1);

            let mut text_100 = text_1.clone();
            let mut fixed_100 = fixed_1.clone();
            for _ in 1..100 {
                let read_f64 = text_100.parse::<f64>().unwrap();
                fixed_100 = FixedPointNumber::try_from(read_f64).unwrap();
                text_100 = format!("{}", fixed_100);
            }

            assert!(fixed_1.to_f64() - fixed_100.to_f64() < 1e-4);
        }
    }

    // --- Fuzz Test for detect_csv_unsafe_chars ---

    #[test]
    fn fuzz_detect_csv_unsafe_chars() {
        let mut rng = rand::rng();
        for _ in 0..1000 {
            let len = rng.random_range(1..50);
            let s: String = (0..len)
                .map(|_| rng.random_range(0x20u8..0x7Fu8) as char) // ASCII range
                .collect();
            let _ = detect_ssv_unsafe_chars(&s);
        }
    }
}

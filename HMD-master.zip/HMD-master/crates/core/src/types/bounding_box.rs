use nalgebra::{Matrix3, Point3, Vector3};
use uom::si::f64::*;
use uom::si::length::nanometer;

use crate::units::util::{nm_to_f64_point, nm_to_f64_vector, point_in_nm, vector_in_nm};

// TODO: BoundingBoxにoriginを追加
#[derive(Debug, Clone, PartialEq)]
pub struct BoundingBox {
    origin: Point3<f64>,
    avec: Vector3<f64>,
    bvec: Vector3<f64>,
    cvec: Vector3<f64>,
}

impl BoundingBox {
    pub fn default() -> Self {
        Self {
            origin: Point3::new(0.0, 0.0, 0.0),
            avec: Vector3::new(0.0, 0.0, 0.0),
            bvec: Vector3::new(0.0, 0.0, 0.0),
            cvec: Vector3::new(0.0, 0.0, 0.0),
        }
    }

    pub fn new(
        origin: Point3<f64>,
        avec: Vector3<f64>,
        bvec: Vector3<f64>,
        cvec: Vector3<f64>,
    ) -> Self {
        Self {
            origin,
            avec,
            bvec,
            cvec,
        }
    }

    pub fn with_unit(
        origin: Point3<Length>,
        avec: Vector3<Length>,
        bvec: Vector3<Length>,
        cvec: Vector3<Length>,
    ) -> Self {
        Self {
            origin: nm_to_f64_point(origin),
            avec: nm_to_f64_vector(avec),
            bvec: nm_to_f64_vector(bvec),
            cvec: nm_to_f64_vector(cvec),
        }
    }

    pub fn set_origin(&mut self, origin: Point3<f64>) {
        self.origin = origin;
    }

    pub fn set_avec(&mut self, avec: Vector3<f64>) {
        self.avec = avec;
    }

    pub fn set_bvec(&mut self, bvec: Vector3<f64>) {
        self.bvec = bvec;
    }

    pub fn set_cvec(&mut self, cvec: Vector3<f64>) {
        self.cvec = cvec;
    }

    pub fn set_origin_with_unit(&mut self, origin: Point3<Length>) {
        self.set_origin(nm_to_f64_point(origin));
    }

    pub fn set_avec_with_unit(&mut self, avec: Vector3<Length>) {
        self.set_avec(nm_to_f64_vector(avec));
    }

    pub fn set_bvec_with_unit(&mut self, bvec: Vector3<Length>) {
        self.set_bvec(nm_to_f64_vector(bvec));
    }

    pub fn set_cvec_with_unit(&mut self, cvec: Vector3<Length>) {
        self.set_cvec(nm_to_f64_vector(cvec));
    }

    pub fn set_origin_x(&mut self, x: f64) {
        self.origin.x = x;
    }

    pub fn set_origin_y(&mut self, y: f64) {
        self.origin.y = y;
    }

    pub fn set_origin_z(&mut self, z: f64) {
        self.origin.z = z;
    }

    pub fn set_avec_x(&mut self, x: f64) {
        self.avec.x = x;
    }

    pub fn set_avec_y(&mut self, y: f64) {
        self.avec.y = y;
    }

    pub fn set_avec_z(&mut self, z: f64) {
        self.avec.z = z;
    }

    pub fn set_bvec_x(&mut self, x: f64) {
        self.bvec.x = x;
    }

    pub fn set_bvec_y(&mut self, y: f64) {
        self.bvec.y = y;
    }

    pub fn set_bvec_z(&mut self, z: f64) {
        self.bvec.z = z;
    }

    pub fn set_cvec_x(&mut self, x: f64) {
        self.cvec.x = x;
    }

    pub fn set_cvec_y(&mut self, y: f64) {
        self.cvec.y = y;
    }

    pub fn set_cvec_z(&mut self, z: f64) {
        self.cvec.z = z;
    }

    pub fn origin(&self) -> &Point3<f64> {
        &self.origin
    }

    pub fn avec(&self) -> &Vector3<f64> {
        &self.avec
    }

    pub fn bvec(&self) -> &Vector3<f64> {
        &self.bvec
    }

    pub fn cvec(&self) -> &Vector3<f64> {
        &self.cvec
    }

    pub fn origin_with_unit(&self) -> Point3<Length> {
        point_in_nm(self.origin.x, self.origin.y, self.origin.z)
    }

    pub fn avec_with_unit(&self) -> Vector3<Length> {
        vector_in_nm(self.avec.x, self.avec.y, self.avec.z)
    }

    pub fn bvec_with_unit(&self) -> Vector3<Length> {
        vector_in_nm(self.bvec.x, self.bvec.y, self.bvec.z)
    }

    pub fn cvec_with_unit(&self) -> Vector3<Length> {
        vector_in_nm(self.cvec.x, self.cvec.y, self.cvec.z)
    }

    pub fn origin_mut(&mut self) -> &mut Point3<f64> {
        &mut self.origin
    }

    pub fn avec_mut(&mut self) -> &mut Vector3<f64> {
        &mut self.avec
    }

    pub fn bvec_mut(&mut self) -> &mut Vector3<f64> {
        &mut self.bvec
    }

    pub fn cvec_mut(&mut self) -> &mut Vector3<f64> {
        &mut self.cvec
    }

    pub fn as_matrix(&self) -> Matrix3<f64> {
        Matrix3::from_columns(&[self.avec, self.bvec, self.cvec])
    }

    pub fn as_matrix_with_unit(&self) -> Matrix3<Length> {
        Matrix3::new(
            Length::new::<nanometer>(self.avec.x),
            Length::new::<nanometer>(self.avec.y),
            Length::new::<nanometer>(self.avec.z), // 1st column
            Length::new::<nanometer>(self.bvec.x),
            Length::new::<nanometer>(self.bvec.y),
            Length::new::<nanometer>(self.bvec.z), // 2nd column
            Length::new::<nanometer>(self.cvec.x),
            Length::new::<nanometer>(self.cvec.y),
            Length::new::<nanometer>(self.cvec.z), // 3rd column
        )
    }
}

use crate::DefaultIdx;
use rustc_hash::FxHashMap;
use std::fmt::Display;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct NameCode(u8);

impl NameCode {
    pub(crate) fn new(num: u8) -> Self {
        Self(num)
    }

    pub(crate) fn to_u8(self) -> u8 {
        self.0
    }
}

// stringを直接ラベルにするとメモリ消費や比較コストが高いためより高速な型で代用する
// &strをラベル名にしてポインタの値で同一性をチェックしても良いが、strの値を誤って比較する可能性がある
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct NameEncoder {
    code2name: FxHashMap<NameCode, String>,
    name2code: FxHashMap<String, NameCode>,
}

#[derive(Debug)]
pub enum NameEncoderError {
    TooManyNameError {
        table: Vec<(String, NameCode)>,
        limit: usize,
    },
}

impl Display for NameEncoderError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::TooManyNameError { table, limit } => {
                write!(f, "too many names are registered: limit = {}", limit)?;
                for (name, code) in table {
                    write!(f, "{}: {}", name, code.to_u8())?;
                }
                Ok(())
            }
        }
    }
}

impl NameEncoder {
    pub(crate) fn new() -> Self {
        Self {
            code2name: FxHashMap::default(),
            name2code: FxHashMap::default(),
        }
    }

    pub(crate) fn from_hashmap(compact: FxHashMap<String, NameCode>) -> Self {
        let friendly = compact.iter().map(|(k, v)| (*v, k.clone())).collect();

        Self {
            code2name: friendly,
            name2code: compact,
        }
    }

    pub(crate) fn from_list(code: Vec<u8>, name: Vec<String>) -> Self {
        assert_eq!(code.len(), name.len());
        let name_code: FxHashMap<String, NameCode> = code
            .into_iter()
            .zip(name.into_iter())
            .map(|(c, n)| (n, NameCode(c)))
            .collect();

        Self::from_hashmap(name_code)
    }

    pub(crate) fn encode_name(&mut self, name: &str) -> Result<NameCode, NameEncoderError> {
        assert_eq!(self.code2name.len(), self.name2code.len());

        // 既に登録されている場合は登録済みNameCodeを返す
        if self.name2code.contains_key(name) {
            let existing_code = self.name2code[name];
            assert!(self.code2name.contains_key(&existing_code));
            return Ok(existing_code);
        }

        // u8の最大値を超えるとエラーを返す
        if self.code2name.len() >= u8::MAX as usize {
            return Err(NameEncoderError::TooManyNameError {
                table: self
                    .code2name
                    .iter()
                    .map(|(k, v)| (v.clone(), k.clone()))
                    .collect(),
                limit: u8::MAX as usize,
            });
        }

        let key = NameCode(self.code2name.len() as u8);
        assert!(self.name2code.insert(name.to_string(), key).is_none());
        assert!(self.code2name.insert(key, name.to_string()).is_none());

        Ok(key)
    }

    pub(crate) fn has_name(&self, name: &str) -> bool {
        self.name2code.contains_key(name)
    }

    pub(crate) fn has_code(&self, name: NameCode) -> bool {
        self.code2name.contains_key(&name)
    }

    pub(crate) fn get_name(&self, raw_name: NameCode) -> Option<&str> {
        self.code2name.get(&raw_name).map(|s| s.as_str())
    }

    pub(crate) fn names(&self) -> Vec<String> {
        self.code2name.values().cloned().collect()
    }

    pub(crate) fn get_code(&self, name: &str) -> Option<NameCode> {
        self.name2code.get(name).copied()
    }

    pub(crate) fn codes(&self) -> Vec<NameCode> {
        self.name2code.values().cloned().collect()
    }

    pub(crate) fn pairs(&self) -> impl Iterator<Item = (&NameCode, &String)> {
        self.code2name.iter()
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub enum StructureKind {
    Polymer,
    Monomer,
    Crosslink,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub struct SubStructure {
    kind: StructureKind,
    name: NameCode,
    index: DefaultIdx,
}

impl SubStructure {
    pub fn new(kind: StructureKind, name: NameCode, index: DefaultIdx) -> Self {
        Self { kind, name, index }
    }

    pub fn kind(&self) -> StructureKind {
        self.kind
    }

    pub fn name(&self) -> NameCode {
        self.name
    }

    pub fn index(&self) -> DefaultIdx {
        self.index
    }

    pub fn pair(&self) -> (NameCode, DefaultIdx) {
        (self.name, self.index)
    }

    pub fn triple(&self) -> (StructureKind, NameCode, DefaultIdx) {
        (self.kind, self.name, self.index)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_name_encoder_basic_registration() {
        let mut encoder = NameEncoder::new();

        let a = encoder.encode_name("a").unwrap();
        let b = encoder.encode_name("b").unwrap();
        let c = encoder.encode_name("c").unwrap();

        assert_eq!(encoder.get_name(a), Some("a"));
        assert_eq!(encoder.get_name(b), Some("b"));
        assert_eq!(encoder.get_name(c), Some("c"));

        assert_eq!(encoder.get_code("a"), Some(a));
        assert_eq!(encoder.get_code("b"), Some(b));
        assert_eq!(encoder.get_code("c"), Some(c));

        assert!(encoder.has_name("a"));
        assert!(encoder.has_code(a));
        assert!(!encoder.has_name("d"));

        let names = encoder.names();
        assert!(names.contains(&"a".to_string()));
        assert!(names.contains(&"b".to_string()));
        assert!(names.contains(&"c".to_string()));

        let codes = encoder.codes();
        assert!(codes.contains(&a));
        assert!(codes.contains(&b));
        assert!(codes.contains(&c));
    }

    #[test]
    fn test_name_encoder_re_register_same_name() {
        let mut encoder = NameEncoder::new();
        let x1 = encoder.encode_name("x").unwrap();
        let x2 = encoder.encode_name("x").unwrap();
        assert_eq!(x1, x2);
    }

    #[test]
    fn test_name_encoder_too_many_names() {
        let mut encoder = NameEncoder::new();

        for i in 0..=u8::MAX {
            let name = format!("name_{}", i);
            let result = encoder.encode_name(&name);
            if i < u8::MAX {
                assert!(result.is_ok());
            } else {
                assert!(result.is_err());
                match result {
                    Err(NameEncoderError::TooManyNameError { table, limit }) => {
                        assert_eq!(limit, 255); // 実際の登録は0〜254まで成功し255でエラー
                        assert_eq!(table.len(), 255);
                    }
                    _ => panic!("unexpected error type"),
                }
            }
        }
    }

    #[test]
    fn test_substructure_basic_behavior() {
        let name_code = NameCode::new(42);
        let index: DefaultIdx = 7;
        let sub = SubStructure::new(StructureKind::Monomer, name_code, index);

        assert_eq!(sub.kind(), StructureKind::Monomer);
        assert_eq!(sub.name(), name_code);
        assert_eq!(sub.index(), index);
        assert_eq!(sub.pair(), (name_code, index));
        assert_eq!(sub.triple(), (StructureKind::Monomer, name_code, index));
    }

    #[test]
    fn test_name_encoder_pairs() {
        let mut encoder = NameEncoder::new();
        let a = encoder.encode_name("alpha").unwrap();
        let b = encoder.encode_name("beta").unwrap();

        let mut pairs: Vec<_> = encoder.pairs().collect();
        pairs.sort_by_key(|(code, _)| code.to_u8());

        assert_eq!(pairs.len(), 2);
        assert!(
            pairs
                .iter()
                .any(|(code, name)| **code == a && *name == "alpha")
        );
        assert!(
            pairs
                .iter()
                .any(|(code, name)| **code == b && *name == "beta")
        );
    }
}

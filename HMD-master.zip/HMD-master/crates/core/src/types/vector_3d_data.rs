use nalgebra::{Point3, Vector3};
use std::ops::Index;

pub trait R3Set: Default + Sized {
    type Item: Default + Sized + Index<usize, Output = f64>;

    fn zeros(n: usize) -> Self;
    fn value_of(&self, i: usize) -> &Self::Item;
    fn set_value(&mut self, i: usize, value: Self::Item);
    fn add_item(&mut self, item: Self::Item) -> usize;
    fn as_slice(&self) -> &[Self::Item];
    fn set_value_x(&mut self, i: usize, value: f64);
    fn set_value_y(&mut self, i: usize, value: f64);
    fn set_value_z(&mut self, i: usize, value: f64);
    fn iter(&self) -> std::slice::Iter<Self::Item>;
    fn iter_mut(&mut self) -> std::slice::IterMut<Self::Item>;

    fn from_iter(iter: impl Iterator<Item = Self::Item>) -> Self {
        let mut set = Self::default();
        for x in iter {
            set.add_item(x);
        }
        set
    }

    fn count(&self) -> usize {
        self.as_slice().len()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Positions {
    positions: Vec<Point3<f64>>,
}

impl Positions {
    pub fn new() -> Self {
        Self {
            positions: Vec::new(),
        }
    }
}

impl Default for Positions {
    fn default() -> Self {
        Self::new()
    }
}

impl R3Set for Positions {
    type Item = Point3<f64>;

    fn zeros(n: usize) -> Self {
        let mut v = Self {
            positions: Vec::with_capacity(n),
        };

        for _ in 0..n {
            v.positions.push(Point3::new(0.0, 0.0, 0.0));
        }

        v
    }

    #[inline(always)]
    fn value_of(&self, i: usize) -> &Point3<f64> {
        &(self.positions[i])
    }

    #[inline(always)]
    fn set_value(&mut self, i: usize, value: Point3<f64>) {
        self.positions[i] = value;
    }

    #[inline(always)]
    fn add_item(&mut self, item: Point3<f64>) -> usize {
        self.positions.push(item);
        self.positions.len() - 1
    }

    #[inline(always)]
    fn as_slice(&self) -> &[Point3<f64>] {
        self.positions.as_slice()
    }

    #[inline(always)]
    fn set_value_x(&mut self, i: usize, value: f64) {
        self.positions[i].x = value;
    }

    #[inline(always)]
    fn set_value_y(&mut self, i: usize, value: f64) {
        self.positions[i].y = value;
    }

    #[inline(always)]
    fn set_value_z(&mut self, i: usize, value: f64) {
        self.positions[i].z = value;
    }

    #[inline(always)]
    fn iter(&self) -> std::slice::Iter<Point3<f64>> {
        self.positions.iter()
    }

    #[inline(always)]
    fn iter_mut(&mut self) -> std::slice::IterMut<Point3<f64>> {
        self.positions.iter_mut()
    }
}

impl<'a> IntoIterator for &'a Positions {
    type Item = &'a Point3<f64>;
    type IntoIter = std::slice::Iter<'a, Point3<f64>>;

    fn into_iter(self) -> Self::IntoIter {
        self.positions.iter()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Velocities {
    velocities: Vec<Vector3<f64>>,
}

impl Default for Velocities {
    fn default() -> Self {
        Self::new()
    }
}

impl Velocities {
    pub fn new() -> Self {
        Self {
            velocities: Vec::new(),
        }
    }
}

impl R3Set for Velocities {
    type Item = Vector3<f64>;

    fn zeros(n: usize) -> Self {
        let mut v = Self {
            velocities: Vec::with_capacity(n),
        };

        for _ in 0..n {
            v.velocities.push(Vector3::new(0.0, 0.0, 0.0));
        }

        v
    }

    #[inline(always)]
    fn value_of(&self, i: usize) -> &Vector3<f64> {
        &(self.velocities[i])
    }

    #[inline(always)]
    fn set_value(&mut self, i: usize, value: Vector3<f64>) {
        self.velocities[i] = value;
    }

    #[inline(always)]
    fn add_item(&mut self, item: Vector3<f64>) -> usize {
        self.velocities.push(item);
        self.velocities.len() - 1
    }

    #[inline(always)]
    fn as_slice(&self) -> &[Vector3<f64>] {
        self.velocities.as_slice()
    }

    #[inline(always)]
    fn set_value_x(&mut self, i: usize, value: f64) {
        self.velocities[i].x = value;
    }

    #[inline(always)]
    fn set_value_y(&mut self, i: usize, value: f64) {
        self.velocities[i].y = value;
    }

    #[inline(always)]
    fn set_value_z(&mut self, i: usize, value: f64) {
        self.velocities[i].z = value;
    }

    #[inline(always)]
    fn iter(&self) -> std::slice::Iter<Vector3<f64>> {
        self.velocities.iter()
    }

    #[inline(always)]
    fn iter_mut(&mut self) -> std::slice::IterMut<Vector3<f64>> {
        self.velocities.iter_mut()
    }
}

impl<'a> IntoIterator for &'a Velocities {
    type Item = &'a Vector3<f64>;
    type IntoIter = std::slice::Iter<'a, Vector3<f64>>;

    fn into_iter(self) -> Self::IntoIter {
        self.velocities.iter()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Forces {
    forces: Vec<Vector3<f64>>,
}

impl Default for Forces {
    fn default() -> Self {
        Self::new()
    }
}

impl Forces {
    pub fn new() -> Self {
        Self { forces: Vec::new() }
    }
}

impl R3Set for Forces {
    type Item = Vector3<f64>;

    fn zeros(n: usize) -> Self {
        let mut v = Self {
            forces: Vec::with_capacity(n),
        };

        for _ in 0..n {
            v.forces.push(Vector3::new(0.0, 0.0, 0.0));
        }

        v
    }

    #[inline(always)]
    fn value_of(&self, i: usize) -> &Vector3<f64> {
        &(self.forces[i])
    }

    #[inline(always)]
    fn set_value(&mut self, i: usize, value: Vector3<f64>) {
        self.forces[i] = value;
    }

    #[inline(always)]
    fn add_item(&mut self, item: Vector3<f64>) -> usize {
        self.forces.push(item);
        self.forces.len() - 1
    }

    #[inline(always)]
    fn as_slice(&self) -> &[Vector3<f64>] {
        self.forces.as_slice()
    }

    #[inline(always)]
    fn set_value_x(&mut self, i: usize, value: f64) {
        self.forces[i].x = value;
    }

    #[inline(always)]
    fn set_value_y(&mut self, i: usize, value: f64) {
        self.forces[i].y = value;
    }

    #[inline(always)]
    fn set_value_z(&mut self, i: usize, value: f64) {
        self.forces[i].z = value;
    }

    #[inline(always)]
    fn iter(&self) -> std::slice::Iter<Vector3<f64>> {
        self.forces.iter()
    }

    #[inline(always)]
    fn iter_mut(&mut self) -> std::slice::IterMut<Vector3<f64>> {
        self.forces.iter_mut()
    }
}

impl<'a> IntoIterator for &'a Forces {
    type Item = &'a Vector3<f64>;
    type IntoIter = std::slice::Iter<'a, Vector3<f64>>;

    fn into_iter(self) -> Self::IntoIter {
        self.forces.iter()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nalgebra::{Point3, Vector3};

    #[test]
    fn test_positions_basic() {
        let mut pos = Positions::new();
        assert_eq!(pos.count(), 0);

        let index = pos.add_item(Point3::new(1.0, 2.0, 3.0));
        assert_eq!(index, 0);
        assert_eq!(pos.count(), 1);
        assert_eq!(*pos.value_of(0), Point3::new(1.0, 2.0, 3.0));

        pos.set_value(0, Point3::new(4.0, 5.0, 6.0));
        assert_eq!(*pos.value_of(0), Point3::new(4.0, 5.0, 6.0));

        pos.set_value_x(0, 7.0);
        pos.set_value_y(0, 8.0);
        pos.set_value_z(0, 9.0);
        assert_eq!(*pos.value_of(0), Point3::new(7.0, 8.0, 9.0));
    }

    #[test]
    fn test_positions_from_iter_and_zeros() {
        let iter = vec![Point3::new(1.0, 1.0, 1.0), Point3::new(2.0, 2.0, 2.0)].into_iter();
        let pos = Positions::from_iter(iter);
        assert_eq!(pos.count(), 2);

        let zeros = Positions::zeros(3);
        assert_eq!(zeros.count(), 3);
        for p in zeros.iter() {
            assert_eq!(*p, Point3::origin());
        }
    }

    #[test]
    fn test_velocities_basic() {
        let mut vel = Velocities::new();
        assert_eq!(vel.count(), 0);

        let index = vel.add_item(Vector3::new(1.0, 2.0, 3.0));
        assert_eq!(index, 0);
        assert_eq!(vel.count(), 1);
        assert_eq!(*vel.value_of(0), Vector3::new(1.0, 2.0, 3.0));

        vel.set_value(0, Vector3::new(4.0, 5.0, 6.0));
        vel.set_value_x(0, 7.0);
        vel.set_value_y(0, 8.0);
        vel.set_value_z(0, 9.0);
        assert_eq!(*vel.value_of(0), Vector3::new(7.0, 8.0, 9.0));
    }

    #[test]
    fn test_velocities_from_iter_and_zeros() {
        let iter = vec![Vector3::new(1.0, 0.0, 0.0), Vector3::new(0.0, 1.0, 0.0)].into_iter();
        let vel = Velocities::from_iter(iter);
        assert_eq!(vel.count(), 2);

        let zeros = Velocities::zeros(2);
        for v in zeros.iter() {
            assert_eq!(*v, Vector3::zeros());
        }
    }

    #[test]
    fn test_forces_basic() {
        let mut force = Forces::new();
        assert_eq!(force.count(), 0);

        let index = force.add_item(Vector3::new(0.1, 0.2, 0.3));
        assert_eq!(index, 0);
        assert_eq!(force.count(), 1);
        assert_eq!(*force.value_of(0), Vector3::new(0.1, 0.2, 0.3));

        force.set_value(0, Vector3::new(1.0, 1.0, 1.0));
        force.set_value_x(0, 2.0);
        force.set_value_y(0, 3.0);
        force.set_value_z(0, 4.0);
        assert_eq!(*force.value_of(0), Vector3::new(2.0, 3.0, 4.0));
    }

    #[test]
    fn test_forces_from_iter_and_zeros() {
        let f = Forces::from_iter(
            vec![Vector3::new(1.0, 1.0, 1.0), Vector3::new(2.0, 2.0, 2.0)].into_iter(),
        );
        assert_eq!(f.count(), 2);

        let zeros = Forces::zeros(3);
        for f in zeros.iter() {
            assert_eq!(*f, Vector3::zeros());
        }
    }
}

//use std::ops::Range;

//mod lammps_data;
//mod lammps_dump;
//mod hmd_text;

//pub struct HMDTextTrajectoryHandle {
//    head_file: std::fs::File,
//    basename: String,
//    suffix: Range
//}

use nalgebra::{Point3, Vector3};
use uom::si::f64::*;
use uom::si::{
    force::piconewton, length::nanometer, mass::dalton, mass_density::gram_per_cubic_centimeter,
    time::nanosecond, volume::cubic_nanometer,
};

// utility functions
pub mod util {
    use super::velocity::nanometer_per_nanosecond;
    use super::*;

    pub fn f64_in_nm(val: f64) -> Length {
        Length::new::<nanometer>(val)
    }

    pub fn nm_to_f64(val: Length) -> f64 {
        val.get::<nanometer>()
    }

    pub fn f64_in_ps(val: f64) -> Time {
        Time::new::<nanosecond>(val)
    }

    pub fn ps_to_f64(val: Time) -> f64 {
        val.get::<nanosecond>()
    }

    pub fn f64_in_nm_per_ns(val: f64) -> Velocity {
        Velocity::new::<nanometer_per_nanosecond>(val)
    }

    pub fn nm_per_ns_to_f64(val: Velocity) -> f64 {
        val.get::<nanometer_per_nanosecond>()
    }

    pub fn f64_in_pn(val: f64) -> Force {
        Force::new::<piconewton>(val)
    }

    pub fn pn_to_f64(val: Force) -> f64 {
        val.get::<piconewton>()
    }

    pub fn f64_in_dalton(val: f64) -> Mass {
        Mass::new::<dalton>(val)
    }

    pub fn dalton_to_f64(val: Mass) -> f64 {
        val.get::<dalton>()
    }

    pub fn f64_in_g_per_cm3(val: f64) -> MassDensity {
        MassDensity::new::<gram_per_cubic_centimeter>(val)
    }

    pub fn g_per_cm3_to_f64(val: MassDensity) -> f64 {
        val.get::<gram_per_cubic_centimeter>()
    }

    pub fn f64_in_nm3(val: f64) -> Volume {
        Volume::new::<cubic_nanometer>(val)
    }

    pub fn nm3_to_f64(val: Volume) -> f64 {
        val.get::<cubic_nanometer>()
    }

    pub fn point_in_nm(x: f64, y: f64, z: f64) -> Point3<Length> {
        Point3::new(f64_in_nm(x), f64_in_nm(y), f64_in_nm(z))
    }

    pub fn nm_to_f64_point(p: Point3<Length>) -> Point3<f64> {
        Point3::new(nm_to_f64(p.x), nm_to_f64(p.y), nm_to_f64(p.z))
    }

    pub fn vector_in_nm(x: f64, y: f64, z: f64) -> Vector3<Length> {
        Vector3::new(f64_in_nm(x), f64_in_nm(y), f64_in_nm(z))
    }

    pub fn nm_to_f64_vector(v: Vector3<Length>) -> Vector3<f64> {
        Vector3::new(nm_to_f64(v.x), nm_to_f64(v.y), nm_to_f64(v.z))
    }

    pub fn vector_in_nm_per_ns(x: f64, y: f64, z: f64) -> Vector3<Velocity> {
        Vector3::new(
            f64_in_nm_per_ns(x),
            f64_in_nm_per_ns(y),
            f64_in_nm_per_ns(z),
        )
    }

    pub fn nm_per_ns_to_f64_vector(v: Vector3<Velocity>) -> Vector3<f64> {
        Vector3::new(
            nm_per_ns_to_f64(v.x),
            nm_per_ns_to_f64(v.y),
            nm_per_ns_to_f64(v.z),
        )
    }

    pub fn vector_in_pn(x: f64, y: f64, z: f64) -> Vector3<Force> {
        Vector3::new(f64_in_pn(x), f64_in_pn(y), f64_in_pn(z))
    }

    pub fn pn_to_f64_vector(v: Vector3<Force>) -> Vector3<f64> {
        Vector3::new(pn_to_f64(v.x), pn_to_f64(v.y), pn_to_f64(v.z))
    }
}

pub mod energy {
    uom::unit! {
        system: uom::si;
        quantity: uom::si::energy;

        @electronvolt: 1.602176634e-19; "eV" , "eV" , "eV";
        @attojoule: 1.0e-18; "aJ" , "aJ" , "aJ";
        @kilojoule: 1000.0; "kJ" , "kJ" , "kJ";
        @calorie: 4.184; "cal" , "cal" , "cal";
        @kilocalorie: 4184.0; "kcal" , "kcal" , "kcal";
    }
}

pub mod velocity {
    uom::unit! {
        system: uom::si;
        quantity: uom::si::velocity;

        @angstrom_per_femtosecond: 100000.0; "Å/fs" , "Å/fs" , "Å/fs";
        @angstrom_per_picosecond: 100.0; "Å/ps" , "Å/ps" , "Å/ps";
        @nanometer_per_picosecond: 1000.0; "nm/ps" , "nm/ps" , "nm/ps";
        @nanometer_per_nanosecond: 1.0; "nm/ns" , "nm/ns" , "nm/ns";
        @micrometer_per_microsecond: 1.0; "μm/μs" , "μm/μs" , "μm/μs";
        @micrometer_per_millisecond: 0.001; "μm/ms" , "μm/ms" , "μm/ms";
    }
}

pub mod force {
    uom::unit! {
        system: uom::si;
        quantity: uom::si::force;

        @piconewton: 1.0e-12; "pN" , "pN" , "pN";
        @nanonewton: 1.0e-9; "nN" , "nN" , "nN";
        @electronvolt_per_angstrom: 1.6021766339999998e-9; "eV/Å" , "eV/Å" , "eV/Å";
        @electronvolt_per_nanometer: 1.6021766339999998e-10; "eV/nm" , "eV/nm" , "eV/nm";
    }
}

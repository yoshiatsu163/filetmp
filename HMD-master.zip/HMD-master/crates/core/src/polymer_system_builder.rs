use std::fmt::Display;
use std::fmt::Write;

use arrayvec::ArrayVec;
use nalgebra::{Point3, Vector3};
use rustc_hash::FxHashMap;

use uom::si::f64::*;
use uom::si::time::nanosecond;

use crate::types::{
    bounding_box::BoundingBox,
    label_util::{NameEncoder, StructureKind, SubStructure},
    util::{AtomProperty, detect_ssv_unsafe_chars},
};
use crate::units::util::*;
use crate::{DefaultIdx, MAX_BONDS};

// このエラーを受け取る可能性があるのは
// 1. ファイル入力時
// 2. トラジェクトリ読み込み時 (ユーザーには無関係)
// 3. 何らかのアルゴリズムでpolymersystemを構築するとき
#[derive(Debug)]
pub enum SystemBuilderError {
    TooManyNeighbors { msg: String },
    OutOfRange { msg: String },
    DuplicateAtom { msg: String },
    SelfLoop { msg: String },
    DuplicateBond { msg: String },
    IllegalStructureName { msg: String },
    TooManyStructureNames { msg: String },
    OverWriteStructure { msg: String },
}

#[derive(Debug, Clone)]
pub struct BondedAtom {
    pub index: usize,
    pub order: u8,
}

impl Display for BondedAtom {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{{ index: {}, order: {} }}", self.index, self.order)
    }
}

#[derive(Debug, Clone)]
pub struct BuilderAtom {
    pub index: usize,
    pub atomic_number: u8,
    pub position: Point3<f64>,
    pub velocity: Option<Vector3<f64>>,
    pub force: Option<Vector3<f64>>,

    polymer_chain: Option<SubStructure>,
    monomer: Option<SubStructure>,
    crosslink: Option<SubStructure>,
    pub property: AtomProperty,

    neighbors: ArrayVec<BondedAtom, MAX_BONDS>,
}

impl Display for BuilderAtom {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "BuilderAtom {{ \n")?;
        write!(f, "    index: {},\n", self.index)?;
        write!(f, "    atomic_number: {},\n", self.atomic_number)?;
        write!(f, "    position: {:?},\n", self.position)?;
        write!(f, "    velocity: {:?},\n", self.velocity)?;
        write!(f, "    force: {:?},\n", self.force)?;
        write!(f, "    polymer_chain: {:?},\n", self.polymer_chain)?;
        write!(f, "    monomer: {:?},\n", self.monomer)?;
        write!(f, "    crosslink: {:?},\n", self.crosslink)?;
        write!(f, "    property: {:?},\n", self.property)?;
        write!(f, "    neighbors: {:?},\n", self.neighbors)?;
        write!(f, "}}")?;
        Ok(())
    }
}

impl BuilderAtom {
    pub fn new(index: usize, atomic_number: u8, position: Point3<f64>) -> Self {
        Self {
            index,
            atomic_number,
            position,
            velocity: None,
            force: None,
            polymer_chain: None,
            monomer: None,
            crosslink: None,
            property: AtomProperty::Unset,
            neighbors: ArrayVec::new(),
        }
    }

    pub fn add_neighbor(&mut self, neighbor: usize, order: u8) -> Result<(), SystemBuilderError> {
        if self.neighbors.len() >= MAX_BONDS {
            let mut msg = format!(
                "{}:{}: SystemBuilderError: atom {} has too many neighbors",
                file!(),
                line!(),
                self.index
            );
            writeln!(msg, "    neighbors: {:?}", self.neighbors()).unwrap();
            return Err(SystemBuilderError::TooManyNeighbors { msg });
        }
        if self.neighbors.iter().any(|bonded| bonded.index == neighbor) {
            let mut msg = format!(
                "{}:{}: SystemBuilderError: atom {} already has bond to {}",
                file!(),
                line!(),
                self.index,
                neighbor
            );
            writeln!(msg, "    neighbors: {:?}", self.neighbors()).unwrap();
            return Err(SystemBuilderError::DuplicateBond { msg });
        }

        self.neighbors.push(BondedAtom {
            index: neighbor,
            order,
        });
        Ok(())
    }

    pub fn neighbors(&self) -> &[BondedAtom] {
        &self.neighbors
    }

    pub fn neighbor_indices(&self) -> impl Iterator<Item = usize> + '_ {
        self.neighbors.iter().map(|bonded| bonded.index)
    }

    pub fn neighbor_bond_orders(&self) -> impl Iterator<Item = u8> + '_ {
        self.neighbors.iter().map(|bonded| bonded.order)
    }

    pub fn polymer_chain(&self) -> Option<SubStructure> {
        self.polymer_chain.clone()
    }

    pub fn monomer(&self) -> Option<SubStructure> {
        self.monomer.clone()
    }

    pub fn crosslink(&self) -> Option<SubStructure> {
        self.crosslink.clone()
    }

    // unit api
    pub fn set_position_with_unit(&mut self, position: Point3<Length>) {
        self.position = nm_to_f64_point(position);
    }

    pub fn set_velocity_with_unit(&mut self, velocity: Vector3<Velocity>) {
        self.velocity = Some(nm_per_ns_to_f64_vector(velocity));
    }

    pub fn set_force_with_unit(&mut self, force: Vector3<Force>) {
        self.force = Some(pn_to_f64_vector(force));
    }
}

pub struct PolymerSystemBuilder {
    pub time: f64, // nanoseconds
    pub timestep: usize,
    pub bbox: BoundingBox,
    pub atoms: FxHashMap<usize, BuilderAtom>,
    pub(crate) name_encoder: NameEncoder, // store readable names of labels
}

impl PolymerSystemBuilder {
    pub fn new() -> Self {
        Self {
            time: 0.0,
            timestep: 0,
            bbox: BoundingBox::default(),
            atoms: FxHashMap::default(),
            name_encoder: NameEncoder::new(),
        }
    }

    pub(crate) fn replace_name_encoder(&mut self, name_encoder: NameEncoder) {
        self.name_encoder = name_encoder;
    }

    pub fn set_time(&mut self, time: f64) {
        self.time = time;
    }

    pub fn set_time_with_unit(&mut self, time: Time) {
        self.time = time.get::<nanosecond>();
    }

    pub fn set_timestep(&mut self, timestep: usize) {
        self.timestep = timestep;
    }

    pub fn set_origin(&mut self, origin: Point3<f64>) {
        self.bbox.set_origin(origin);
    }

    pub fn set_avec(&mut self, avec: Vector3<f64>) {
        self.bbox.set_avec(avec);
    }

    pub fn set_bvec(&mut self, bvec: Vector3<f64>) {
        self.bbox.set_bvec(bvec);
    }

    pub fn set_cvec(&mut self, cvec: Vector3<f64>) {
        self.bbox.set_cvec(cvec);
    }

    pub fn set_origin_with_unit(&mut self, origin: Point3<Length>) {
        self.bbox.set_origin(nm_to_f64_point(origin));
    }

    pub fn set_avec_with_unit(&mut self, avec: Vector3<Length>) {
        self.bbox.set_avec(nm_to_f64_vector(avec));
    }

    pub fn set_bvec_with_unit(&mut self, bvec: Vector3<Length>) {
        self.bbox.set_bvec(nm_to_f64_vector(bvec));
    }

    pub fn set_cvec_with_unit(&mut self, cvec: Vector3<Length>) {
        self.bbox.set_cvec(nm_to_f64_vector(cvec));
    }

    pub fn add_atom(&mut self, atom: BuilderAtom) -> Result<(), SystemBuilderError> {
        if self.atoms.contains_key(&atom.index) {
            return Err(SystemBuilderError::DuplicateAtom {
                msg: format!(
                    "{}: {}: SystemBuilderError: atom with index {} already exists",
                    file!(),
                    line!(),
                    atom.index
                ),
            });
        }
        self.atoms.insert(atom.index, atom);
        Ok(())
    }

    pub fn add_bond(
        &mut self,
        from: usize,
        to: usize,
        order: u8,
    ) -> Result<(), SystemBuilderError> {
        if from == to {
            return Err(SystemBuilderError::SelfLoop {
                msg: format!(
                    "{}: {}: SystemBuilderError: self-loop bond from {} to {} with order {}",
                    file!(),
                    line!(),
                    from,
                    to,
                    order
                ),
            });
        }

        if !(self.atoms.contains_key(&from) && self.atoms.contains_key(&to)) {
            return Err(SystemBuilderError::OutOfRange {
                msg: format!(
                    "{}:{}: SystemBuilderError: atom index out of range: (from, to) = ({}, {})",
                    file!(),
                    line!(),
                    from,
                    to
                ),
            });
        }

        // from,　toの片方だけに問題がある場合はselfに変更を加える前にエラー検知が必要
        // add_neighbo()の戻り値で判定するとdungling bondが発生しうる
        if self.degree(from) == MAX_BONDS || self.degree(to) == MAX_BONDS {
            let mut msg = format!(
                "{}:{}: SystemBuilderError: atom {} or {} has too many neighbors\n",
                file!(),
                line!(),
                from,
                to
            );
            let nbr_from = self.neighbors(from).collect::<Vec<_>>();
            let nbr_to = self.neighbors(to).collect::<Vec<_>>();
            writeln!(msg, "    neighbors of atom {}: {:?}\n", from, nbr_from).unwrap();
            writeln!(msg, "    neighbors of atom {}: {:?}\n", to, nbr_to).unwrap();
            return Err(SystemBuilderError::TooManyNeighbors { msg });
        }

        if self.has_bond(from, to) {
            let mut msg = format!(
                "{}:{}: SystemBuilderError: bond from {} to {} already exists\n",
                file!(),
                line!(),
                from,
                to
            );
            let nbr_from = self.neighbors(from).collect::<Vec<_>>();
            let nbr_to = self.neighbors(to).collect::<Vec<_>>();
            writeln!(msg, "    neighbors of atom {}: {:?}\n", from, nbr_from).unwrap();
            writeln!(msg, "    neighbors of atom {}: {:?}\n", to, nbr_to).unwrap();
            return Err(SystemBuilderError::DuplicateBond { msg });
        }

        let from_atom = self.atoms.get_mut(&from).unwrap();
        assert_eq!(from_atom.index, from);
        from_atom.add_neighbor(to, order).unwrap();

        let to_atom = self.atoms.get_mut(&to).unwrap();
        assert_eq!(to_atom.index, to);
        to_atom.add_neighbor(from, order).unwrap();

        Ok(())
    }

    pub fn has_bond(&self, from: usize, to: usize) -> bool {
        self.atoms[&from]
            .neighbors
            .iter()
            .any(|bonded| bonded.index == to)
    }

    pub fn neighbors(&self, idx: usize) -> impl Iterator<Item = usize> + '_ {
        self.atoms[&idx].neighbors.iter().map(|bonded| bonded.index)
    }

    pub fn set_substructure(
        &mut self,
        index: usize,
        category: StructureKind,
        label_name: &str,
        label_index: usize,
    ) -> Result<(), SystemBuilderError> {
        match detect_ssv_unsafe_chars(label_name) {
            Ok(_) => (),
            Err(err) => {
                let sub_msg = format!("{}", err);
                return Err(SystemBuilderError::IllegalStructureName {
                    msg: format!(
                        "{}: {}: SystemBuilderError:\n\n{}",
                        file!(),
                        line!(),
                        sub_msg
                    ),
                });
            }
        }
        let code = match self.name_encoder.encode_name(label_name) {
            Ok(code) => code,
            Err(err) => {
                return Err(SystemBuilderError::TooManyStructureNames {
                    msg: format!(
                        "{}: {}: SystemBuilderError: too many structure names\n\n{}",
                        file!(),
                        line!(),
                        err
                    ),
                });
            }
        };

        let sub_structure = SubStructure::new(category, code, label_index as DefaultIdx);
        let store = match category {
            StructureKind::Polymer => &mut self.atoms.get_mut(&index).unwrap().polymer_chain,
            StructureKind::Monomer => &mut self.atoms.get_mut(&index).unwrap().monomer,
            StructureKind::Crosslink => &mut self.atoms.get_mut(&index).unwrap().crosslink,
        };
        if store.is_some() {
            return Err(SystemBuilderError::OverWriteStructure {
                msg: format!(
                    "{}:{}: SystemBuilderError: atom {} already has a structure\n",
                    file!(),
                    line!(),
                    index
                ),
            });
        }
        *store = Some(sub_structure);
        Ok(())
    }

    pub fn degree(&self, idx: usize) -> usize {
        self.atoms[&(idx as usize)].neighbors().len()
    }

    pub fn natoms(&self) -> usize {
        self.atoms.len()
    }

    pub fn nbonds(&self) -> usize {
        self.atoms
            .iter()
            .map(|(_, atom)| atom.neighbors().len())
            .sum::<usize>()
            / 2
    }
}

#[cfg(test)]
mod test {
    use crate::polymer_system_builder::{BuilderAtom, PolymerSystemBuilder};
    use crate::types::label_util::StructureKind;
    use crate::units::util::*;
    use nalgebra::{point, vector};
    use num::rational::Ratio;

    use super::SystemBuilderError;

    #[test]
    fn test_builder_atom_creation_and_neighbors() -> Result<(), SystemBuilderError> {
        let mut atom = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        assert_eq!(atom.index, 0);
        assert_eq!(atom.atomic_number, 6);
        assert_eq!(atom.neighbors().len(), 0);

        atom.add_neighbor(1, 1)?;
        assert_eq!(atom.neighbors().len(), 1);
        assert_eq!(atom.neighbor_indices().collect::<Vec<_>>(), vec![1]);
        Ok(())
    }

    #[test]
    fn test_set_units_on_atom() {
        let mut atom = BuilderAtom::new(0, 1, point![0.0, 0.0, 0.0]);
        atom.set_position_with_unit(point![f64_in_nm(1.0), f64_in_nm(0.0), f64_in_nm(0.0)]);
        atom.set_velocity_with_unit(vector![
            f64_in_nm_per_ns(0.1),
            f64_in_nm_per_ns(0.0),
            f64_in_nm_per_ns(0.0),
        ]);
        atom.set_force_with_unit(vector![f64_in_pn(10.0), f64_in_pn(0.0), f64_in_pn(0.0)]);

        assert!(
            (atom.position - point![1.0, 0.0, 0.0])
                .iter()
                .all(|&x| x < 1.0e-10)
        );
        assert!(
            (atom.velocity.unwrap() - vector![0.1, 0.0, 0.0])
                .iter()
                .all(|&x| x < 1.0e-10)
        );
        assert!(
            (atom.force.unwrap() - vector![10.0, 0.0, 0.0])
                .iter()
                .all(|&x| x < 1.0e-10)
        );
    }

    #[test]
    fn test_polymer_system_builder_add_atom_and_bond() -> Result<(), SystemBuilderError> {
        let mut builder = PolymerSystemBuilder::new();
        let atom1 = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        let atom2 = BuilderAtom::new(1, 1, point![1.0, 0.0, 0.0]);
        builder.add_atom(atom1)?;
        builder.add_atom(atom2)?;

        builder.add_bond(0, 1, 1)?;

        assert_eq!(builder.atoms[&0].neighbors().len(), 1);
        assert_eq!(builder.atoms[&1].neighbors().len(), 1);
        Ok(())
    }

    #[test]
    fn test_add_duplicate_atom() {
        let mut builder = PolymerSystemBuilder::new();
        let atom1 = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        assert!(builder.add_atom(atom1).is_ok());

        let atom2 = BuilderAtom::new(0, 6, point![1.0, 0.0, 0.0]);
        assert!(match builder.add_atom(atom2) {
            Err(SystemBuilderError::DuplicateAtom { .. }) => true,
            _ => false,
        });
    }

    #[test]
    fn test_duplicate_bond_atom() {
        let mut atom = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        let bo = 1;
        assert!(atom.add_neighbor(1, bo).is_ok());
        assert!(match atom.add_neighbor(1, bo) {
            Err(SystemBuilderError::DuplicateBond { .. }) => true,
            _ => false,
        });
    }

    #[test]
    fn test_too_many_neighbors() {
        let mut atom = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        for i in 0..crate::MAX_BONDS {
            assert!(atom.add_neighbor(i, 1).is_ok());
        }

        let bo = 1;
        let n = crate::MAX_BONDS;
        assert!(match atom.add_neighbor(n, bo) {
            Err(SystemBuilderError::TooManyNeighbors { .. }) => true,
            _ => false,
        });
    }

    #[test]
    fn test_duplicate_bond() {
        let mut builder = PolymerSystemBuilder::new();
        let atom1 = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        let atom2 = BuilderAtom::new(1, 6, point![1.0, 0.0, 0.0]);
        assert!(builder.add_atom(atom1).is_ok());
        assert!(builder.add_atom(atom2).is_ok());
        let bo = 1;
        assert!(builder.add_bond(0, 1, bo).is_ok());
        assert!(match builder.add_bond(1, 0, bo) {
            Err(SystemBuilderError::DuplicateBond { .. }) => true,
            _ => false,
        });
    }

    #[test]
    fn test_self_loop() {
        let mut builder = PolymerSystemBuilder::new();
        let atom1 = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        let atom2 = BuilderAtom::new(1, 6, point![0.0, 0.0, 0.0]);
        assert!(builder.add_atom(atom1).is_ok());
        assert!(builder.add_atom(atom2).is_ok());
        let bo = 1;
        assert!(builder.add_bond(0, 1, bo).is_ok());
        assert!(match builder.add_bond(1, 1, bo) {
            Err(SystemBuilderError::SelfLoop { .. }) => true,
            _ => false,
        });
    }

    #[test]
    fn test_set_substructure() {
        let mut builder = PolymerSystemBuilder::new();
        let atom = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        let pol = StructureKind::Polymer;
        assert!(builder.add_atom(atom).is_ok());
        assert!(builder.set_substructure(0, pol, "polymer", 0).is_ok());
        assert!(match builder.set_substructure(0, pol, "日本語", 0) {
            Err(SystemBuilderError::IllegalStructureName { .. }) => true,
            _ => false,
        });
        assert!(match builder.set_substructure(0, pol, "po,lymer", 0) {
            Err(SystemBuilderError::IllegalStructureName { .. }) => true,
            _ => false,
        });
    }
}

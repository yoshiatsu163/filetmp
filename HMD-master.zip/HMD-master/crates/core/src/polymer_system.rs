use arrayvec::ArrayVec;
use nalgebra::{Point3, Vector3};
use std::collections::VecDeque;
//use petgraph::graph::{NodeIndex, UnGraph};
//use petgraph::visit::Bfs;
use fixedbitset::FixedBitSet;
use rustc_hash::FxHashMap;
use std::ops::Range;

use uom::si::f64::*;
use uom::si::force::piconewton;
use uom::si::length::nanometer;
use uom::si::mass::dalton;
use uom::si::time::nanosecond;

use crate::types::util::SelfLoopError;
use crate::units::util::*;
use crate::units::velocity::nanometer_per_nanosecond;
use crate::{ATOMIC_MASS, DefaultIdx, MAX_BONDS};
use crate::{
    polymer_system_builder::{BondedAtom, BuilderAtom, PolymerSystemBuilder},
    types::{
        bounding_box::BoundingBox,
        label_util::{NameEncoder, StructureKind, SubStructure},
        util::{AtomProperty, Bond, BondPair, FixedPointNumber},
        vector_3d_data::{Forces, Positions, R3Set, Velocities},
    },
};

fn vector3_in_nm(val: f64) -> Vector3<Length> {
    Vector3::new(
        Length::new::<nanometer>(val),
        Length::new::<nanometer>(val),
        Length::new::<nanometer>(val),
    )
}

fn atomid_into_defaultidx(atom_id: usize) -> DefaultIdx {
    let Ok(idx) = atom_id.try_into() else {
        panic!("atom_id {} is too large for DefaultIdx type", atom_id);
    };
    idx
}

pub enum PolymerSystemError {
    SelfLoopError { msg: String },
    StructureNotFoundError { msg: String },
    WrongStructureKindError { msg: String },
    SanityCheckError { msg: String },
    FinalizeError { msg: String },
}

#[derive(Clone, PartialEq)]
pub struct PolymerSystem {
    time: f64, // nanoseconds
    timestep: usize,

    neighbor_list: Vec<ArrayVec<DefaultIdx, MAX_BONDS>>,
    bbox: BoundingBox,
    positions: Positions,
    velocities: Option<Velocities>,
    forces: Option<Forces>,

    atomic_numbers: Vec<u8>,
    bond_orders: FxHashMap<BondPair, u8>,

    // structure labels
    // label means some structure like "Styrene", "polymer chain"
    name_encoder: NameEncoder, // store readable names of labels

    // mapping: atom -> belonging structure
    polymer_chains: Vec<Option<SubStructure>>,
    monomers: Vec<Option<SubStructure>>,
    crosslinks: Vec<Option<SubStructure>>,
    // mapping: structure -> atoms
    structure_atoms: FxHashMap<SubStructure, Range<DefaultIdx>>,

    // atom wise propertie
    atomic_properties: Vec<AtomProperty>,
}

impl Default for PolymerSystem {
    fn default() -> Self {
        Self::new()
    }
}

// low level apis
impl PolymerSystem {
    fn new() -> Self {
        Self {
            time: 0.0,
            timestep: 0,

            neighbor_list: Vec::new(),
            bbox: BoundingBox::new(
                Point3::default(),
                Vector3::default(),
                Vector3::default(),
                Vector3::default(),
            ),
            positions: Positions::new(), // nanometer
            velocities: None,            // nm/ns
            forces: None,                // pN
            atomic_numbers: Vec::new(),
            bond_orders: FxHashMap::default(),

            name_encoder: NameEncoder::new(),
            polymer_chains: Vec::new(),
            monomers: Vec::new(),
            crosslinks: Vec::new(),
            structure_atoms: FxHashMap::default(),
            atomic_properties: Vec::new(),
        }
    }

    #[inline(always)]
    pub fn time(&self) -> f64 {
        self.time
    }

    #[inline(always)]
    pub fn timestep(&self) -> usize {
        self.timestep
    }

    #[inline(always)]
    pub fn neighbor_list(&self) -> &[ArrayVec<DefaultIdx, MAX_BONDS>] {
        self.neighbor_list.as_slice()
    }

    #[inline(always)]
    pub(crate) fn name_encoder(&self) -> &NameEncoder {
        &self.name_encoder
    }

    #[inline(always)]
    pub fn bbox(&self) -> &BoundingBox {
        &self.bbox
    }

    #[inline(always)]
    pub fn positions(&self) -> &Positions {
        &self.positions
    }

    #[inline(always)]
    pub fn positions_mut(&mut self) -> &mut Positions {
        &mut self.positions
    }

    #[inline(always)]
    pub fn position(&self, idx: DefaultIdx) -> &Point3<f64> {
        self.positions.value_of(idx as usize)
    }

    #[inline(always)]
    pub fn velocities(&self) -> Option<&Velocities> {
        self.velocities.as_ref()
    }

    #[inline(always)]
    pub fn velocities_mut(&mut self) -> Option<&mut Velocities> {
        self.velocities.as_mut()
    }

    #[inline(always)]
    pub fn velocity(&self, idx: DefaultIdx) -> Option<&Vector3<f64>> {
        self.velocities
            .as_ref()
            .map(|velocities| velocities.value_of(idx as usize))
    }

    #[inline(always)]
    pub fn forces(&self) -> Option<&Forces> {
        self.forces.as_ref()
    }

    #[inline(always)]
    pub fn forces_mut(&mut self) -> Option<&mut Forces> {
        self.forces.as_mut()
    }

    #[inline(always)]
    pub fn force(&self, idx: DefaultIdx) -> Option<&Vector3<f64>> {
        self.forces
            .as_ref()
            .map(|forces| forces.value_of(idx as usize))
    }

    #[inline(always)]
    pub fn atomic_numbers(&self) -> &[u8] {
        self.atomic_numbers.as_slice()
    }

    #[inline(always)]
    pub fn polymer_chains(&self) -> &[Option<SubStructure>] {
        self.polymer_chains.as_slice()
    }

    #[inline(always)]
    pub fn monomers(&self) -> &[Option<SubStructure>] {
        self.monomers.as_slice()
    }

    #[inline(always)]
    pub fn crosslinks(&self) -> &[Option<SubStructure>] {
        self.crosslinks.as_slice()
    }

    #[inline(always)]
    pub fn structure_atoms(&self) -> &FxHashMap<SubStructure, Range<DefaultIdx>> {
        &self.structure_atoms
    }

    #[inline(always)]
    pub fn atomic_properties(&self) -> &[AtomProperty] {
        self.atomic_properties.as_slice()
    }

    #[inline(always)]
    pub(crate) fn swap_positions(&mut self, positions: Positions) -> Positions {
        std::mem::replace(&mut self.positions, positions)
    }

    #[inline(always)]
    pub(crate) fn swap_velocities(&mut self, velocities: Velocities) -> Velocities {
        if self.velocities.is_none() {
            panic!("Velocities must be already initialized");
        }
        std::mem::replace(&mut self.velocities, Some(velocities)).unwrap()
    }

    #[inline(always)]
    pub(crate) fn swap_forces(&mut self, forces: Forces) -> Forces {
        if self.forces.is_none() {
            panic!("Forces must be already initialized");
        }
        std::mem::replace(&mut self.forces, Some(forces)).unwrap()
    }

    #[inline(always)]
    pub(crate) fn swap_label_registry(&mut self, label_registry: NameEncoder) -> NameEncoder {
        std::mem::replace(&mut self.name_encoder, label_registry)
    }

    #[inline(always)]
    pub(crate) fn swap_structure_atoms(
        &mut self,
        structure_atoms: FxHashMap<SubStructure, Range<DefaultIdx>>,
    ) -> FxHashMap<SubStructure, Range<DefaultIdx>> {
        std::mem::replace(&mut self.structure_atoms, structure_atoms)
    }

    #[inline(always)]
    pub(crate) fn swap_bool_structures(
        &mut self,
        bool_structures: Vec<AtomProperty>,
    ) -> Vec<AtomProperty> {
        std::mem::replace(&mut self.atomic_properties, bool_structures)
    }

    #[inline(always)]
    pub fn natoms(&self) -> usize {
        assert_eq!(self.positions.count(), self.neighbor_list.len());
        if let Some(ref velocities) = self.velocities {
            assert_eq!(velocities.count(), self.neighbor_list.len());
        }
        if let Some(ref forces) = self.forces {
            assert_eq!(forces.count(), self.neighbor_list.len());
        }

        self.neighbor_list.len()
    }

    #[inline(always)]
    pub fn nbonds(&self) -> usize {
        let n = self
            .neighbor_list
            .iter()
            .map(|bond_list| bond_list.len())
            .sum::<usize>();
        let half = n / 2;
        assert_eq!(n - half - half, 0);
        half
    }

    #[inline(always)]
    pub fn has_velocity(&self) -> bool {
        self.velocities.is_some()
    }

    #[inline(always)]
    pub fn has_force(&self) -> bool {
        self.forces.is_some()
    }

    #[inline(always)]
    pub fn bond_order(&self, head: DefaultIdx, tail: DefaultIdx) -> u8 {
        let bp = match BondPair::new(head, tail) {
            Ok(bp) => bp,
            Err(SelfLoopError) => {
                eprintln!(
                    "{}: {}: Self loop detected: {}-{}",
                    file!(),
                    line!(),
                    head,
                    tail
                );
                panic!()
            }
        };
        self.bond_orders[&bp]
    }
}

// high level apis
impl PolymerSystem {
    pub fn bond_iter(&self) -> impl Iterator<Item = Bond> {
        self.bond_orders
            .iter()
            .map(|(&bp, &order)| Bond::new(bp.small, bp.big, order).unwrap())
    }

    #[inline(always)]
    pub fn time_with_unit(&self) -> Time {
        Time::new::<nanosecond>(self.time)
    }

    pub fn positions_wrapped(&self) -> impl Iterator<Item = Point3<f64>> {
        // ボックス座標系への基底変換
        let mat = self.bbox().as_matrix().try_inverse().unwrap();
        let origin = self.bbox().origin().clone();
        let avec = self.bbox().avec().clone();
        let bvec = self.bbox().bvec().clone();
        let cvec = self.bbox().cvec().clone();
        let box_coords = self.positions().iter().map(move |pos| {
            let box_coord = mat * (pos - origin);
            let box_coord_wrapped_x = box_coord.x.fract();
            let box_coord_wrapped_y = box_coord.y.fract();
            let box_coord_wrapped_z = box_coord.z.fract();
            Point3::from(
                box_coord_wrapped_x * avec
                    + box_coord_wrapped_y * bvec
                    + box_coord_wrapped_z * cvec
                    + origin.coords,
            )
        });
        box_coords
    }

    pub fn positions_wrapped_image(&self) -> impl Iterator<Item = (Point3<f64>, [i16; 3])> {
        // ボックス座標系への基底変換
        let mat = self.bbox().as_matrix().try_inverse().unwrap();
        let origin = self.bbox().origin().clone();
        let result = self.positions().iter().map(move |pos| {
            let box_coord = mat * (pos - origin);
            let box_coord_wrapped_x = box_coord.x.fract();
            let box_image_x = box_coord.x.floor() as i16;
            let box_coord_wrapped_y = box_coord.y.fract();
            let box_image_y = box_coord.y.floor() as i16;
            let box_coord_wrapped_z = box_coord.z.fract();
            let box_image_z = box_coord.z.floor() as i16;
            let pos = Point3::from(
                box_coord_wrapped_x * self.bbox().avec()
                    + box_coord_wrapped_y * self.bbox().bvec()
                    + box_coord_wrapped_z * self.bbox().cvec()
                    + origin.coords,
            );
            (pos, [box_image_x, box_image_y, box_image_z])
        });
        result
    }

    #[inline(always)]
    pub fn position_with_unit(&self, atom_id: DefaultIdx) -> Point3<Length> {
        Point3::new(
            Length::new::<nanometer>(self.positions.value_of(atom_id as usize).x),
            Length::new::<nanometer>(self.positions.value_of(atom_id as usize).y),
            Length::new::<nanometer>(self.positions.value_of(atom_id as usize).z),
        )
    }

    #[inline(always)]
    pub fn velocity_with_unit(&self, atom_id: DefaultIdx) -> Option<Vector3<Velocity>> {
        match self.velocities {
            Some(ref velocities) => Some(Vector3::new(
                Velocity::new::<nanometer_per_nanosecond>(velocities.value_of(atom_id as usize).x),
                Velocity::new::<nanometer_per_nanosecond>(velocities.value_of(atom_id as usize).y),
                Velocity::new::<nanometer_per_nanosecond>(velocities.value_of(atom_id as usize).z),
            )),
            None => None,
        }
    }

    #[inline(always)]
    pub fn force_with_unit(&self, atom_id: DefaultIdx) -> Option<Vector3<Force>> {
        match self.forces {
            Some(ref forces) => Some(Vector3::new(
                Force::new::<piconewton>(forces.value_of(atom_id as usize).x),
                Force::new::<piconewton>(forces.value_of(atom_id as usize).y),
                Force::new::<piconewton>(forces.value_of(atom_id as usize).z),
            )),
            None => None,
        }
    }

    pub fn all_structures(&self) -> impl Iterator<Item = &SubStructure> {
        self.structure_atoms.keys()
    }

    #[inline(always)]
    pub fn atom_prop(&self, atom_id: DefaultIdx) -> AtomProperty {
        self.atomic_properties[atom_id as usize]
    }

    #[inline(always)]
    pub fn is_backbone(&self, atom_id: DefaultIdx) -> bool {
        match self.atomic_properties[atom_id as usize] {
            AtomProperty::Backbone => true,
            _ => false,
        }
    }

    #[inline(always)]
    pub fn is_backbone_terminal(&self, atom_id: DefaultIdx) -> bool {
        match self.atomic_properties[atom_id as usize] {
            AtomProperty::BackboneTerminal => true,
            _ => false,
        }
    }

    #[inline(always)]
    pub fn polymer_chain(&self, atom_id: DefaultIdx) -> Option<&SubStructure> {
        self.polymer_chains[atom_id as usize].as_ref()
    }

    #[inline(always)]
    pub fn monomer(&self, atom_id: DefaultIdx) -> Option<&SubStructure> {
        self.monomers[atom_id as usize].as_ref()
    }

    #[inline(always)]
    pub fn crosslink(&self, atom_id: DefaultIdx) -> Option<&SubStructure> {
        self.crosslinks[atom_id as usize].as_ref()
    }

    #[inline(always)]
    pub fn under_polymer(&self, atom_id: DefaultIdx) -> bool {
        self.polymer_chains[atom_id as usize].is_some()
    }

    #[inline(always)]
    pub fn under_monomer(&self, atom_id: DefaultIdx) -> bool {
        self.monomers[atom_id as usize].is_some()
    }

    #[inline(always)]
    pub fn under_crosslink(&self, atom_id: DefaultIdx) -> bool {
        self.crosslinks[atom_id as usize].is_some()
    }

    pub fn atoms_under<'a, 'b>(&'a self, label: &'b SubStructure) -> Range<DefaultIdx> {
        match self.structure_atoms.get(label) {
            Some(range) => range.clone(),
            None => {
                eprintln!("structure {:?} is not found in the system", label);
                panic!()
            }
        }
    }

    pub fn polymer_atoms<'a, 'b>(&'a self, label: &'b SubStructure) -> Range<DefaultIdx> {
        if label.kind() != StructureKind::Polymer {
            eprintln!("structure {:?} is not a polymer", label);
            panic!()
        }
        self.atoms_under(label)
    }

    pub fn monomer_atoms<'a, 'b>(&'a self, label: &'b SubStructure) -> Range<DefaultIdx> {
        if label.kind() != StructureKind::Monomer {
            eprintln!("structure {:?} is not a monomer", label);
            panic!()
        }
        self.atoms_under(label)
    }

    pub fn crosslink_atoms<'a, 'b>(&'a self, label: &'b SubStructure) -> Range<DefaultIdx> {
        if label.kind() != StructureKind::Crosslink {
            eprintln!("structure {:?} is not a crosslink", label);
            panic!()
        }
        self.atoms_under(label)
    }

    pub fn all_polymers(&self) -> impl Iterator<Item = &SubStructure> {
        self.structure_atoms
            .keys()
            .filter(|l| l.kind() == StructureKind::Polymer)
    }

    pub fn all_monomers(&self) -> impl Iterator<Item = &SubStructure> {
        self.structure_atoms
            .keys()
            .filter(|l| l.kind() == StructureKind::Monomer)
    }

    pub fn all_crosslinks(&self) -> impl Iterator<Item = &SubStructure> {
        self.structure_atoms
            .keys()
            .filter(|l| l.kind() == StructureKind::Crosslink)
    }

    // ラベルがらみのcombinator実装
}

// systemの情報にAtomのメソッドからアクセスするための糖衣構文
#[derive(Clone)]
pub struct AtomView<'a> {
    index: DefaultIdx,
    system: &'a PolymerSystem,
}

impl PolymerSystem {
    #[inline(always)]
    pub fn view(&self, idx: DefaultIdx) -> AtomView<'_> {
        AtomView {
            index: idx,
            system: self,
        }
    }

    #[inline(always)]
    pub fn views(&self) -> impl Iterator<Item = AtomView<'_>> {
        (0..self.natoms()).map(move |idx| self.view(idx as DefaultIdx))
    }

    #[inline(always)]
    pub fn views_with<T, I>(&self, range: T) -> impl Iterator<Item = AtomView<'_>>
    where
        T: Iterator<Item = I>,
        I: Copy + Into<DefaultIdx>,
    {
        range.map(move |idx| self.view(idx.into()))
    }

    #[inline(always)]
    pub fn views_under<'a, 'b>(
        &'a self,
        label: &'b SubStructure,
    ) -> impl Iterator<Item = AtomView<'a>> {
        self.atoms_under(label)
            .into_iter()
            .map(|idx| self.view(idx))
    }
}

impl<'a> AtomView<'a> {
    #[inline(always)]
    pub fn index(&self) -> DefaultIdx {
        self.index
    }

    #[inline(always)]
    pub fn neighbor_indices(&self) -> impl Iterator<Item = DefaultIdx> {
        self.system.neighbor_list[self.index as usize]
            .iter()
            .copied()
    }

    #[inline(always)]
    pub fn neighbor_slice(&self) -> &[DefaultIdx] {
        self.system.neighbor_list[self.index as usize].as_slice()
    }

    #[inline(always)]
    //pub fn neighbors(&self) -> impl Iterator<Item = AtomView<'_>> + use<'_> {
    pub fn neighbors(&self) -> impl Iterator<Item = AtomView<'a>> {
        self.system.neighbor_list[self.index as usize]
            .iter()
            .map(|idx| self.system.view(*idx))
    }

    #[inline(always)]
    pub fn bond_orders(&self) -> impl Iterator<Item = u8> {
        self.system.neighbor_list[self.index as usize]
            .iter()
            .map(|neighbor| self.system.bond_order(*neighbor, self.index))
    }

    #[inline(always)]
    pub fn bond_order(&self, neighbor: DefaultIdx) -> u8 {
        self.system.bond_order(self.index, neighbor)
    }

    #[inline(always)]
    pub fn atomic_number(&self) -> u8 {
        self.system.atomic_numbers[self.index as usize]
    }

    #[inline(always)]
    pub fn mass(&self) -> f64 {
        ATOMIC_MASS[self.atomic_number() as usize]
    }

    #[inline(always)]
    pub fn mass_with_unit(&self) -> Mass {
        Mass::new::<dalton>(self.mass())
    }

    #[inline(always)]
    pub fn position(&self) -> &'_ Point3<f64> {
        self.system.positions.value_of(self.index as usize)
    }

    #[inline(always)]
    pub fn velocity(&self) -> Option<&'_ Vector3<f64>> {
        match self.system.velocities {
            Some(ref velocities) => Some(velocities.value_of(self.index as usize)),
            None => None,
        }
    }

    #[inline(always)]
    pub fn force(&self) -> Option<&'_ Vector3<f64>> {
        match self.system.forces {
            Some(ref forces) => Some(forces.value_of(self.index as usize)),
            None => None,
        }
    }

    #[inline(always)]
    pub fn polymer_chain(&self) -> Option<&'_ SubStructure> {
        self.system.polymer_chains[self.index as usize].as_ref()
    }

    #[inline(always)]
    pub fn monomer(&self) -> Option<&'_ SubStructure> {
        self.system.monomers[self.index as usize].as_ref()
    }

    #[inline(always)]
    pub fn crosslink(&self) -> Option<&'_ SubStructure> {
        self.system.crosslinks[self.index as usize].as_ref()
    }

    #[inline(always)]
    pub fn is_under(&self, label: &SubStructure) -> bool {
        match label.kind() {
            StructureKind::Polymer => {
                self.system.polymer_chains[self.index as usize] == Some(*label)
            }
            StructureKind::Monomer => self.system.monomers[self.index as usize] == Some(*label),
            StructureKind::Crosslink => self.system.crosslinks[self.index as usize] == Some(*label),
        }
    }

    #[inline(always)]
    pub fn under_polymer(&self) -> bool {
        self.system.polymer_chains[self.index as usize].is_some()
    }

    #[inline(always)]
    pub fn not_under_polymer(&self) -> bool {
        self.system.polymer_chains[self.index as usize].is_none()
    }

    #[inline(always)]
    pub fn under_monomer(&self) -> bool {
        self.system.monomers[self.index as usize].is_some()
    }

    #[inline(always)]
    pub fn not_under_monomer(&self) -> bool {
        self.system.monomers[self.index as usize].is_none()
    }

    #[inline(always)]
    pub fn under_crosslink(&self) -> bool {
        self.system.crosslinks[self.index as usize].is_some()
    }

    #[inline(always)]
    pub fn not_under_crosslink(&self) -> bool {
        self.system.crosslinks[self.index as usize].is_none()
    }

    #[inline(always)]
    pub fn property(&self) -> AtomProperty {
        self.system.atomic_properties[self.index as usize]
    }

    #[inline(always)]
    pub fn is_backbone(&self) -> bool {
        match self.system.atomic_properties[self.index as usize] {
            AtomProperty::Backbone => true,
            _ => false,
        }
    }

    #[inline(always)]
    pub fn is_backbone_terminal(&self) -> bool {
        match self.system.atomic_properties[self.index as usize] {
            AtomProperty::BackboneTerminal => true,
            _ => false,
        }
    }

    #[inline(always)]
    pub fn not_backbone(&self) -> bool {
        match self.system.atomic_properties[self.index as usize] {
            AtomProperty::Backbone => false,
            _ => true,
        }
    }

    #[inline(always)]
    pub fn not_backbone_terminal(&self) -> bool {
        match self.system.atomic_properties[self.index as usize] {
            AtomProperty::BackboneTerminal => false,
            _ => true,
        }
    }
}

impl PolymerSystem {
    fn check_no_intersection(
        labels: &FxHashMap<SubStructure, Range<DefaultIdx>>,
        cat: StructureKind,
    ) {
        let mut ranges = labels
            .iter()
            .filter(|(label, _)| label.kind() == cat)
            .map(|(_, range)| range.clone())
            .collect::<Vec<_>>();
        ranges.sort_unstable_by_key(|r| r.start);

        if ranges.is_empty() {
            return;
        }

        // rangesに重複がないかチェック
        ranges.as_slice().windows(2).for_each(|w| {
            if w[0].end >= w[1].start {
                eprintln!("Overlapping 2 ranges detected:");
                eprintln!("    {:?}: {}-{}", cat, w[0].start, w[0].end);
                eprintln!("    {:?}: {}-{}", cat, w[1].start, w[1].end);
                panic!();
            }
        });

        if ranges[0].start != 0 {
            eprintln!("First range of {:?} is not starting from 0", cat);
            eprintln!("    {:?}: {}-{}", cat, ranges[0].start, ranges[0].end);
            panic!();
        }
    }

    pub fn sanity_check(&self) {
        // 1. 配列長のチェック
        if self.positions.count() != self.neighbor_list.len() {
            eprintln!(
                "vector length of positions ({}) must match number of atoms ({})",
                self.positions.count(),
                self.neighbor_list.len()
            );
            panic!()
        }
        if let Some(ref vels) = self.velocities {
            if vels.count() != self.neighbor_list.len() {
                eprintln!(
                    "vector length of velocities ({}) must match number of atoms ({})",
                    vels.count(),
                    self.neighbor_list.len()
                );
                panic!()
            }
        }
        if let Some(ref fors) = self.forces {
            if fors.count() != self.neighbor_list.len() {
                eprintln!(
                    "vector length of forces ({}) must match number of atoms ({})",
                    fors.count(),
                    self.neighbor_list.len()
                );
                panic!()
            }
        }

        // structure_atomsの各ラベルに属する原子インデックスがカテゴリー内で重複せず隙間もないことを確認
        Self::check_no_intersection(&self.structure_atoms, StructureKind::Polymer);
        Self::check_no_intersection(&self.structure_atoms, StructureKind::Monomer);
        Self::check_no_intersection(&self.structure_atoms, StructureKind::Crosslink);

        // 各ラベルがstructure_atomsに登録されているか確認
        let mut labels = Vec::<Option<SubStructure>>::new();
        labels.extend_from_slice(&self.polymer_chains);
        labels.extend_from_slice(&self.monomers);
        labels.extend_from_slice(&self.crosslinks);
        labels.iter().for_each(|l| {
            if let Some(label) = l {
                if !self.structure_atoms.contains_key(label) {
                    eprintln!("Polymer chain label {:?} is not registered", label);
                    panic!()
                }
            }
        });

        // 逆向きにstructure_atomsのRangeが一致するか確認
        for (label, range) in &self.structure_atoms {
            let labelvec = match label.kind() {
                StructureKind::Polymer => &self.polymer_chains,
                StructureKind::Monomer => &self.monomers,
                StructureKind::Crosslink => &self.crosslinks,
            };
            for atom_idx in range.clone() {
                if labelvec[atom_idx as usize] != Some(*label) {
                    eprintln!("atom {} is not under label {:?}", atom_idx, label);
                    panic!()
                }
            }
        }

        // TODO: daungling bondのチェック

        // 3. ポリマー鎖特有のルールチェック
        for atom in self.views() {
            if atom.is_backbone() {
                // backboneであればPolmerラベル配下かつ水素ではない
                if atom.not_under_polymer() {
                    eprintln!(
                        "Atom {} is marked main_chain but has no polymer_chain label",
                        atom.index()
                    );
                    panic!()
                }
                if atom.atomic_number() == 1u8 {
                    eprintln!(
                        "Atom {} is marked main_chain but has atomic number 1",
                        atom.index()
                    );
                    panic!()
                }
            }
        }

        // 5. 各ポリマー鎖の連結性
        //   polymer_chains の range に対して連結かどうかを調べる
        for polymer in self.all_polymers() {
            let range = self.polymer_atoms(polymer);
            if range.len() <= 1 {
                continue;
            }

            // BFS で最初の原子からたどれる原子が range 内全部と一致するかをチェック
            let mut bfs = Bfs::new(&self, range.start, |_| true);
            let mut scanned_atoms = Vec::<DefaultIdx>::new();
            while let Some(atom) = bfs.next() {
                scanned_atoms.push(atom);
            }
            scanned_atoms.sort_unstable();
            scanned_atoms.iter().zip(range.clone()).for_each(|(&a, b)| {
                if a != b {
                    eprintln!("Polymer chain {:?} is not connected", polymer);
                    eprintln!("    expected: {:?}", range);
                    eprintln!("    anomarous atom: {}", a);
                    panic!()
                }
            });
        }
    }

    pub(crate) fn finalize_unchecked(builder: PolymerSystemBuilder) -> PolymerSystem {
        let mut fin = PolymerSystem::new();
        fin.time = builder.time;
        fin.timestep = builder.timestep;
        fin.bbox = builder.bbox;
        fin.name_encoder = builder.name_encoder;

        // BuilderAtomをインデックスと共に確保
        let atoms = {
            let mut atoms = builder
                .atoms
                .into_iter()
                .collect::<Vec<(usize, BuilderAtom)>>();
            atoms.sort_unstable_by_key(|(idx, _)| *idx);
            assert!(atoms.iter().all(|(i, atom)| *i == atom.index));
            atoms
                .into_iter()
                .map(|(_, atom)| atom)
                .collect::<Vec<BuilderAtom>>()
        };
        let natoms = atoms.len();

        // BuilderAtomのindexが0から順に並んでいるかどうかをチェック
        if atoms
            .as_slice()
            .windows(2)
            .any(|w| w[0].index + 1 != w[1].index)
        {
            eprintln!("Atom indices are not contiguous");
            panic!()
        }
        assert_eq!(atoms[0].index, 0);
        assert_eq!(atoms.last().unwrap().index, natoms - 1);
        assert!(natoms - 1 < DefaultIdx::MAX as usize);

        // 速度と力がある場合はすべてのBuilderAtomで設定されているかどうかをチェック
        let has_velocity = atoms[0].velocity.is_some();
        let has_force = atoms[0].force.is_some();
        if atoms.iter().any(|a| a.velocity.is_some() != has_velocity) {
            eprintln!("Velocity must be all set or all unset");
            panic!()
        }
        if atoms.iter().any(|a| a.force.is_some() != has_force) {
            eprintln!("Force must be all set or all unset");
            panic!()
        }

        // 位置、速度、力をfinにセット
        fin.positions = Positions::from_iter(atoms.iter().map(|a| a.position));
        if has_velocity {
            fin.velocities = Some(Velocities::from_iter(
                atoms.iter().map(|a| a.velocity.unwrap()),
            ));
        }
        if has_force {
            fin.forces = Some(Forces::from_iter(atoms.iter().map(|a| a.force.unwrap())));
        }

        fin.atomic_numbers = atoms.iter().map(|a| a.atomic_number).collect();
        fin.polymer_chains = atoms.iter().map(|a| a.polymer_chain()).collect();
        fin.monomers = atoms.iter().map(|a| a.monomer()).collect();
        fin.crosslinks = atoms.iter().map(|a| a.crosslink()).collect();
        fin.atomic_properties = atoms.iter().map(|a| a.property).collect();

        // ラベル -> 原子rangeのマップ
        fin.structure_atoms = FxHashMap::default();
        for atom in atoms.iter() {
            let index = DefaultIdx::try_from(atom.index).unwrap();
            [atom.polymer_chain(), atom.monomer(), atom.crosslink()]
                .iter()
                .filter(|l| l.is_some())
                .for_each(|l| {
                    let label = l.unwrap();
                    let range = fin
                        .structure_atoms
                        .entry(label)
                        .or_insert_with(|| Range {
                            start: index,
                            end: index,
                        })
                        .clone();
                    fin.structure_atoms.insert(
                        label,
                        Range {
                            start: range.start.min(index),
                            end: range.end.max(index),
                        },
                    );
                });
        }

        // 隣接リストを原子indexと結合次数に分解してfinにセット
        let adj_list = atoms
            .iter()
            .map(|a| a.neighbors())
            .collect::<Vec<&[BondedAtom]>>();
        assert_eq!(adj_list.iter().map(|l| l.len()).sum::<usize>() % 2, 0);
        for (i, bonded_atoms) in adj_list.iter().enumerate() {
            if bonded_atoms.iter().any(|a| a.index == i) {
                eprintln!("Self-loop detected at atom {}", i);
                panic!()
            }
        }

        fin.bond_orders = FxHashMap::default();
        for (i, bonded_atoms) in adj_list.iter().enumerate() {
            for atom in bonded_atoms.iter() {
                let bp = match BondPair::new(i as DefaultIdx, atom.index as DefaultIdx) {
                    Ok(bp) => bp,
                    Err(SelfLoopError) => {
                        eprintln!(
                            "{}: {}: Self loop detected: {}-{}",
                            file!(),
                            line!(),
                            i,
                            atom.index
                        );
                        panic!()
                    }
                };
                fin.bond_orders.insert(bp, atom.order);
            }
        }

        fin.neighbor_list = Vec::<ArrayVec<DefaultIdx, MAX_BONDS>>::with_capacity(natoms);
        for bonded_atoms in adj_list.iter() {
            fin.neighbor_list.push(
                bonded_atoms
                    .iter()
                    .map(|a| a.index as DefaultIdx)
                    .collect::<ArrayVec<DefaultIdx, MAX_BONDS>>(),
            );
        }

        fin
    }

    pub fn finalize(builder: PolymerSystemBuilder) -> PolymerSystem {
        let fin = Self::finalize_unchecked(builder);
        fin.sanity_check();
        fin
    }
}

pub struct Dfs<'a, F: Fn(&'_ AtomView<'a>) -> bool> {
    system: &'a PolymerSystem,
    visit_list: FixedBitSet,
    stack: Vec<DefaultIdx>,
    selector: F,
}

impl<'a, F: Fn(&'_ AtomView<'a>) -> bool> Dfs<'a, F> {
    pub fn new(system: &'a PolymerSystem, start: DefaultIdx, selector: F) -> Self {
        let n = system.natoms();
        let mut dfs = Self {
            system,
            visit_list: FixedBitSet::with_capacity(n),
            stack: Vec::with_capacity(n / 100),
            selector,
        };

        let atom = system.view(start);
        if (dfs.selector)(&atom) {
            // visit_listはstackからpopされたときにinsertされるのでここではinsertしない
            dfs.stack.push(start);
        }
        dfs
    }

    pub fn visit_list(&self) -> &FixedBitSet {
        &self.visit_list
    }

    pub fn stack(&self) -> &Vec<DefaultIdx> {
        &self.stack
    }

    pub fn is_visited(&self, atom: DefaultIdx) -> bool {
        self.visit_list.contains(atom as usize)
    }

    pub fn not_visited(&self, atom: DefaultIdx) -> bool {
        !self.is_visited(atom)
    }

    pub fn next(&mut self) -> Option<DefaultIdx> {
        while let Some(current) = self.stack.pop() {
            // currentの隣接ノードxをstackにpushしたとき、xとcurrentの共通隣接ノードyが
            // stackに残っていればxがstackに二重に登録される
            // 二回目のxを無視するためstackからpopするたびにvisitedを確認する
            if self.not_visited(current) {
                let current_atom = self.system.view(current);
                for neighbor in current_atom.neighbors() {
                    // Dfsの初期化時点でselectorを通過しているのでneighborに対してのみselectorを通せばよい
                    if self.not_visited(neighbor.index()) && (self.selector)(&neighbor) {
                        self.stack.push(neighbor.index());
                    }
                }
                assert!(self.not_visited(current));
                self.visit_list.insert(current as usize);
                return Some(current);
            }
        }
        None
    }

    pub fn restart(&mut self, start: DefaultIdx) {
        self.stack.clear();
        let start_atom = self.system.view(start);
        if (self.selector)(&start_atom) {
            self.visit_list.insert(start as usize);
            self.stack.push(start_atom.index());
        }
    }
}

pub struct Bfs<'a, F: Fn(&'_ AtomView<'a>) -> bool> {
    system: &'a PolymerSystem,
    visit_list: FixedBitSet,
    queue: VecDeque<DefaultIdx>,
    selector: F,
}

impl<'a, F: Fn(&'_ AtomView<'a>) -> bool> Bfs<'a, F> {
    pub fn new(system: &'a PolymerSystem, start: DefaultIdx, selector: F) -> Self {
        let n = system.natoms();
        let mut bfs = Self {
            system,
            visit_list: FixedBitSet::with_capacity(n),
            queue: VecDeque::with_capacity(n / 100),
            selector,
        };

        let atom = system.view(start);
        if (bfs.selector)(&atom) {
            // visit_listはqueからpopされたときにinsertされるのでここではinsertしない
            bfs.queue.push_back(atom.index());
        }
        bfs
    }

    pub fn visit_list(&self) -> &FixedBitSet {
        &self.visit_list
    }

    pub fn queue(&self) -> &VecDeque<DefaultIdx> {
        &self.queue
    }

    #[inline(always)]
    pub fn is_visited(&self, atom: DefaultIdx) -> bool {
        self.visit_list.contains(atom as usize)
    }

    #[inline(always)]
    pub fn not_visited(&self, atom: DefaultIdx) -> bool {
        !self.is_visited(atom)
    }

    pub fn next(&mut self) -> Option<DefaultIdx> {
        while let Some(current) = self.queue.pop_front() {
            // currentの隣接ノードxをqueueにpush_backしたとき、xとcurrentの共通隣接ノードyが
            // 既にqueue先頭付近に入っていればxがqueueに二重に登録される
            // 二回目のxを無視するためqueueからpop_frontするたびにvisitedを確認する
            if self.not_visited(current) {
                let current_atom = self.system.view(current);
                for neighbor in current_atom.neighbors() {
                    // Bfsの初期化時点でselectorを通過しているのでneighborに対してのみselectorを通せばよい
                    if self.not_visited(neighbor.index()) && (self.selector)(&neighbor) {
                        self.queue.push_back(neighbor.index());
                    }
                }
                assert!(self.not_visited(current));
                self.visit_list.insert(current as usize);
                return Some(current);
            }
        }
        None
    }

    pub fn restart(&mut self, start: DefaultIdx) {
        self.queue.clear();
        let start_atom = self.system.view(start);
        if (self.selector)(&start_atom) {
            self.visit_list.insert(start as usize);
            self.queue.push_back(start_atom.index());
        }
    }
}

pub struct BfsWithDepth<'a, F: Fn(&'_ AtomView<'a>) -> bool> {
    system: &'a PolymerSystem,
    visit_list: FixedBitSet,
    queue: VecDeque<(DefaultIdx, u32)>,
    selector: F,
}

impl<'a, F: Fn(&'_ AtomView<'a>) -> bool> BfsWithDepth<'a, F> {
    pub fn new(system: &'a PolymerSystem, start: DefaultIdx, selector: F) -> Self {
        let n = system.natoms();
        let mut dfs = Self {
            system,
            visit_list: FixedBitSet::with_capacity(n),
            queue: VecDeque::with_capacity(n / 100),
            selector,
        };

        let atom = system.view(start);
        if (dfs.selector)(&atom) {
            // visit_listはqueueからpopされたときにinsertされるのでここではinsertしない
            dfs.queue.push_back((start, 0));
        }
        dfs
    }

    pub fn visit_list(&self) -> &FixedBitSet {
        &self.visit_list
    }

    pub fn queue(&self) -> &VecDeque<(DefaultIdx, u32)> {
        &self.queue
    }

    pub fn is_visited(&self, idx: DefaultIdx) -> bool {
        self.visit_list.contains(idx as usize)
    }

    pub fn not_visited(&self, idx: DefaultIdx) -> bool {
        !self.is_visited(idx)
    }

    pub fn next(&mut self) -> Option<(DefaultIdx, u32)> {
        while let Some((current, depth)) = self.queue.pop_front() {
            // currentの隣接ノードxをqueueにpush_backしたとき、xとcurrentの共通隣接ノードyが
            // 既にqueue先頭付近に入っていればxがqueueに二重に登録される
            // 二回目のxを無視するためqueueからpop_frontするたびにvisitedを確認する
            if self.not_visited(current) {
                let current_atom = self.system.view(current);
                for neighbor in current_atom.neighbors() {
                    // Bfsの初期化時点でselectorを通過しているのでneighborに対してのみselectorを通せばよい
                    if self.not_visited(neighbor.index()) && (self.selector)(&neighbor) {
                        self.queue.push_back((neighbor.index(), depth + 1));
                    }
                }
                assert!(self.not_visited(current));
                self.visit_list.insert(current as usize);
                return Some((current, depth));
            }
        }
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::polymer_system_builder::{BuilderAtom, PolymerSystemBuilder, SystemBuilderError};
    use crate::types::label_util::StructureKind;
    use crate::types::util::{AtomProperty, FixedPointNumber};
    use itertools::Itertools;
    use nalgebra::{Point3, Vector3, point, vector};
    use num::rational::Ratio;
    use rand::Rng;

    #[test]
    fn test_finalize_minimal_system() {
        let mut builder = PolymerSystemBuilder::new();

        let atom0 = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]); // C
        let atom1 = BuilderAtom::new(1, 1, point![1.0, 0.0, 0.0]); // H
        builder.add_atom(atom0).unwrap();
        builder.add_atom(atom1).unwrap();

        builder.add_bond(0, 1, 1).unwrap();

        let system = PolymerSystem::finalize(builder);

        assert_eq!(system.natoms(), 2);
        assert_eq!(system.nbonds(), 1);

        // 原子番号の確認
        assert_eq!(system.atomic_numbers()[0], 6);
        assert_eq!(system.atomic_numbers()[1], 1);

        let bo01 = system.bond_order(0, 1);
        assert_eq!(bo01, 1u8);

        let nbr_0 = system.neighbor_list()[0].as_slice();
        let nbr_1 = system.neighbor_list()[1].as_slice();
        assert_eq!(nbr_0, [1]);
        assert_eq!(nbr_1, [0]);

        system.sanity_check();
    }

    #[test]
    fn test_finalize_with_polymers() {
        let mut builder = PolymerSystemBuilder::new();

        // polymer C-C-C-C
        for i in 0..4 {
            let atom = BuilderAtom::new(i, 6, point![i as f64, 0.0, 0.0]);
            builder.add_atom(atom).unwrap();
        }
        builder.add_bond(0, 1, 1).unwrap();
        builder.add_bond(1, 2, 1).unwrap();
        builder.add_bond(2, 3, 1).unwrap();

        for i in 0..4 {
            builder
                .set_substructure(i, StructureKind::Polymer, "polyA", 0)
                .unwrap();
        }
        let system = PolymerSystem::finalize(builder);

        // 4原子、3結合
        assert_eq!(system.natoms(), 4);
        assert_eq!(system.nbonds(), 3);

        // 全部が同じポリマーラベルを持っている
        for i in 0..4 {
            let poly = system.polymer_chain(i as DefaultIdx);
            assert!(poly.is_some());
            let sub = poly.unwrap();
            assert_eq!(sub.kind(), StructureKind::Polymer);
            // encodeした文字列"polyA"がちゃんと復元できるか
            let namecode = sub.name();
            let recovered_name = system.name_encoder().get_name(namecode).unwrap();
            assert_eq!(recovered_name, "polyA");
        }

        // ポリマーの連結性
        let mut bfs = Bfs::new(&system, 0, |_| true);
        let mut visited = Vec::new();
        while let Some(idx) = bfs.next() {
            visited.push(idx);
        }
        visited.sort_unstable();
        assert_eq!(visited, vec![0, 1, 2, 3]);
        assert!(visited.iter().all(|&a| bfs.is_visited(a)));

        system.sanity_check();
    }

    #[test]
    fn test_positions_wrapped() {
        let mut builder = PolymerSystemBuilder::new();
        builder.set_avec(vector![2.0, 0.0, 0.0]);
        builder.set_bvec(vector![0.0, 2.0, 0.0]);
        builder.set_cvec(vector![0.0, 0.0, 2.0]);

        let atom_in = BuilderAtom::new(0, 6, point![1.0, 1.0, 1.0]);
        let atom_out = BuilderAtom::new(1, 6, point![3.1, 1.5, -0.2]); //[1.1, 1.5, 1.8] when wrapepd
        builder.add_atom(atom_in).unwrap();
        builder.add_atom(atom_out).unwrap();

        let system = PolymerSystem::finalize(builder);
        let wrapped_positions: Vec<_> = system.positions_wrapped().collect();
        assert_eq!(wrapped_positions.len(), 2);

        let not_move = wrapped_positions[0];
        let wrapped = wrapped_positions[1];
        assert!(not_move.x - 1.0 < 1e-10);
        assert!(not_move.y - 1.0 < 1e-10);
        assert!(not_move.z - 1.0 < 1e-10);
        assert!(wrapped.x - 1.1 < 1e-10);
        assert!(wrapped.y - 1.5 < 1e-10);
        assert!(wrapped.z - 1.8 < 1e-10);
    }

    #[test]
    fn test_atom_view_api() {
        let mut builder = PolymerSystemBuilder::new();

        // 三員環
        for i in 0..3 {
            builder
                .add_atom(BuilderAtom::new(i, 6, point![i as f64, 0.0, 0.0]))
                .unwrap();
        }
        builder.add_bond(0, 1, 1).unwrap();
        builder.add_bond(1, 2, 2).unwrap();
        builder.add_bond(2, 0, 3).unwrap();

        let system = PolymerSystem::finalize(builder);

        let atom0 = system.view(0);
        let neighbors0: Vec<_> = atom0.neighbor_indices().collect();
        assert_eq!(neighbors0, vec![1, 2]);

        // 結合次数
        let bo01 = atom0.bond_order(1);
        let bo02 = atom0.bond_order(2);
        assert_eq!(bo01, 1u8);
        assert_eq!(bo02, 3u8);

        let mut sum_index = 0;
        for nbr in atom0.neighbors() {
            sum_index += nbr.index();
        }
        assert_eq!(sum_index, 3); // 1+2=3

        // BFS
        let mut bfs = Bfs::new(&system, 0, |_| true);
        let mut visited = Vec::new();
        while let Some(idx) = bfs.next() {
            visited.push(idx);
        }
        visited.sort_unstable();
        assert_eq!(visited, vec![0, 1, 2]);
    }

    #[test]
    fn test_atom_property_backbone() {
        let mut builder = PolymerSystemBuilder::new();
        // C-C-H
        for i in 0..3 {
            let mut atom =
                BuilderAtom::new(i, if i < 2 { 6 } else { 1 }, point![i as f64, 0.0, 0.0]);
            if i < 2 {
                atom.property = AtomProperty::Backbone;
            }
            builder.add_atom(atom).unwrap();
        }
        builder.add_bond(0, 1, 1).unwrap();
        builder.add_bond(1, 2, 1).unwrap();

        let pol = StructureKind::Polymer;
        builder.set_substructure(0, pol, "polyA", 0).unwrap();
        builder.set_substructure(1, pol, "polyA", 0).unwrap();
        builder.set_substructure(2, pol, "polyA", 0).unwrap();

        let system = PolymerSystem::finalize(builder);
        assert!(system.is_backbone(0));
        assert!(system.is_backbone(1));
        assert!(!system.is_backbone(2));
    }

    #[test]
    fn test_dfs_linear_chain() {
        let mut builder = PolymerSystemBuilder::new();
        // linear polymer 0-1-2-3-4
        for i in 0..5 {
            builder
                .add_atom(BuilderAtom::new(i, 6, point![i as f64, 0.0, 0.0]))
                .unwrap();
            if i > 0 {
                builder.add_bond(i - 1, i, 1).unwrap();
            }
        }
        let system = PolymerSystem::finalize(builder);

        // DFS start = 1
        let mut dfs = Dfs::new(&system, 0, |_| true);
        let mut visited = Vec::new();
        while let Some(idx) = dfs.next() {
            visited.push(idx);
        }

        assert_eq!(visited, vec![0, 1, 2, 3, 4]);
    }

    #[test]
    fn test_bfs_with_depth() {
        let mut builder = PolymerSystemBuilder::new();
        // 3x4 格子 斜め方向の結合は無し
        for i in 0..12 {
            builder
                .add_atom(BuilderAtom::new(i, 6, point![i as f64, 0.0, 0.0]))
                .unwrap();
        }
        let bo = 1;
        builder.add_bond(0, 1, bo).unwrap();
        builder.add_bond(0, 3, bo).unwrap();
        builder.add_bond(1, 4, bo).unwrap();
        builder.add_bond(1, 2, bo).unwrap();
        builder.add_bond(2, 5, bo).unwrap();
        builder.add_bond(3, 4, bo).unwrap();
        builder.add_bond(3, 6, bo).unwrap();
        builder.add_bond(4, 5, bo).unwrap();
        builder.add_bond(4, 7, bo).unwrap();
        builder.add_bond(5, 8, bo).unwrap();
        builder.add_bond(6, 7, bo).unwrap();
        builder.add_bond(6, 9, bo).unwrap();
        builder.add_bond(7, 8, bo).unwrap();
        builder.add_bond(7, 10, bo).unwrap();
        builder.add_bond(8, 11, bo).unwrap();
        builder.add_bond(9, 10, bo).unwrap();
        builder.add_bond(10, 11, bo).unwrap();

        let system = PolymerSystem::finalize(builder);

        let mut bfs = BfsWithDepth::new(&system, 1, |_| true);
        let mut result = vec![];
        while let Some((idx, depth)) = bfs.next() {
            result.push((idx, depth));
        }
        let mut depth0 = result
            .iter()
            .filter(|(_, d)| *d == 0)
            .map(|(a, _)| *a)
            .collect::<Vec<DefaultIdx>>();
        let mut depth1 = result
            .iter()
            .filter(|(_, d)| *d == 1)
            .map(|(a, _)| *a)
            .collect::<Vec<DefaultIdx>>();
        let mut depth2 = result
            .iter()
            .filter(|(_, d)| *d == 2)
            .map(|(a, _)| *a)
            .collect::<Vec<DefaultIdx>>();
        let mut depth3 = result
            .iter()
            .filter(|(_, d)| *d == 3)
            .map(|(a, _)| *a)
            .collect::<Vec<DefaultIdx>>();
        let mut depth4 = result
            .iter()
            .filter(|(_, d)| *d == 4)
            .map(|(a, _)| *a)
            .collect::<Vec<DefaultIdx>>();
        depth0.sort_unstable();
        depth1.sort_unstable();
        depth2.sort_unstable();
        depth3.sort_unstable();
        depth4.sort_unstable();

        assert_eq!(depth0, vec![1]);
        assert_eq!(depth1, vec![0, 2, 4]);
        assert_eq!(depth2, vec![3, 5, 7]);
        assert_eq!(depth3, vec![6, 8, 10]);
        assert_eq!(depth4, vec![9, 11]);
    }

    #[test]
    fn test_traverse_random_connected() {
        let mut rng = rand::rng();
        for _ in 0..10 {
            let mut builder = PolymerSystemBuilder::new();

            // random but connected graph
            let n = rng.random_range(100..200);
            for i in 0..n {
                builder
                    .add_atom(BuilderAtom::new(i, 6, point![i as f64, 0.0, 0.0]))
                    .unwrap();
                if i > 0 {
                    builder.add_bond(i - 1, i, 1).unwrap();
                }
            }

            // random connection
            let nedge = rng.random_range(n..crate::MAX_BONDS * n);
            let mut cnt = 0;
            while builder.nbonds() < nedge {
                let i = rng.random_range(0..n);
                let j = rng.random_range(0..n);
                if i != j {
                    match builder.add_bond(i, j, 1) {
                        Ok(_) => {}
                        Err(SystemBuilderError::DuplicateBond { .. }) => {}
                        Err(SystemBuilderError::TooManyNeighbors { .. }) => {}
                        Err(err) => panic!("unexpected error: {:?}", err),
                    };
                }
                if cnt > 10000 {
                    break;
                }
                cnt += 1;
            }

            let system = PolymerSystem::finalize(builder);

            // random start
            let start = rng.random_range(0..n) as DefaultIdx;
            let mut bfs = Bfs::new(&system, start, |_| true);
            let mut dfs = Dfs::new(&system, start, |_| true);
            let mut bfs_depth = BfsWithDepth::new(&system, start, |_| true);
            while let Some(x) = bfs.next() {}
            while let Some(_) = dfs.next() {}
            while let Some(_) = bfs_depth.next() {}

            assert!((0..n).into_iter().all(|i| bfs.is_visited(i as DefaultIdx)));
            assert!((0..n).into_iter().all(|i| dfs.is_visited(i as DefaultIdx)));
            assert!(
                (0..n)
                    .into_iter()
                    .all(|i| bfs_depth.is_visited(i as DefaultIdx))
            );
        }
    }

    #[test]
    fn test_traverse_random_separated() {
        let mut rng = rand::rng();
        for _ in 0..10 {
            let mut builder = PolymerSystemBuilder::new();

            // random graph composed of 2 separated parts
            let n = rng.random_range(100..200);
            let half = n / 2;
            for i in 0..n {
                builder
                    .add_atom(BuilderAtom::new(i, 6, point![i as f64, 0.0, 0.0]))
                    .unwrap();
                if i > 0 && i != half {
                    builder.add_bond(i - 1, i, 1).unwrap();
                }
            }

            // random connection
            let nedge = rng.random_range(n..crate::MAX_BONDS * n);
            let mut cnt = 0;
            while builder.nbonds() < nedge {
                let i = rng.random_range(0..n);
                let j = rng.random_range(0..n);
                if i != j && (i.max(j) < half || half <= i.min(j)) {
                    match builder.add_bond(i, j, 1) {
                        Ok(_) => {}
                        Err(SystemBuilderError::DuplicateBond { .. }) => {}
                        Err(SystemBuilderError::TooManyNeighbors { .. }) => {}
                        Err(err) => panic!("unexpected error: {:?}", err),
                    };
                }
                if cnt > 20000 {
                    break;
                }
                cnt += 1;
            }

            let system = PolymerSystem::finalize(builder);

            // 前半の連結部分[0..half)からスタート
            let start = rng.random_range(0..half) as DefaultIdx;
            let mut bfs = Bfs::new(&system, start, |_| true);
            let mut dfs = Dfs::new(&system, start, |_| true);
            let mut bfs_depth = BfsWithDepth::new(&system, start, |_| true);
            while let Some(_) = bfs.next() {}
            while let Some(_) = dfs.next() {}
            while let Some(_) = bfs_depth.next() {}

            assert!(
                (0..half)
                    .into_iter()
                    .all(|i| bfs.is_visited(i as DefaultIdx))
            );
            assert!(
                (0..half)
                    .into_iter()
                    .all(|i| dfs.is_visited(i as DefaultIdx))
            );
            assert!(
                (0..half)
                    .into_iter()
                    .all(|i| bfs_depth.is_visited(i as DefaultIdx))
            );

            assert!(
                (half..n)
                    .into_iter()
                    .all(|i| !bfs.is_visited(i as DefaultIdx))
            );
            assert!(
                (half..n)
                    .into_iter()
                    .all(|i| !dfs.is_visited(i as DefaultIdx))
            );
            assert!(
                (half..n)
                    .into_iter()
                    .all(|i| !bfs_depth.is_visited(i as DefaultIdx))
            );
        }
    }

    #[test]
    fn test_bond_order_api() {
        let mut builder = PolymerSystemBuilder::new();
        let mut a0 = BuilderAtom::new(0, 6, point![0.0, 0.0, 0.0]);
        let mut a1 = BuilderAtom::new(1, 8, point![1.0, 0.0, 0.0]);

        a0.add_neighbor(1, 5).unwrap();
        a1.add_neighbor(0, 5).unwrap();

        builder.add_atom(a0).unwrap();
        builder.add_atom(a1).unwrap();

        // finalize
        let system = PolymerSystem::finalize(builder);

        assert_eq!(system.natoms(), 2);
        assert_eq!(system.nbonds(), 1);

        let bo01 = system.bond_order(0, 1);
        assert_eq!(bo01, 5);

        // all_bonds()を用いてBond構造体に変換して取得
        let mut all_bonds = system.bond_iter().collect::<Vec<_>>();
        assert_eq!(all_bonds.len(), 1);
        let b0 = all_bonds.remove(0);
        assert_eq!(b0.small, 0);
        assert_eq!(b0.big, 1);
        assert_eq!(b0.order, 5);
    }
}

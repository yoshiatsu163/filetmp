#[macro_use]
extern crate uom;

//pub mod io;
pub mod polymer_system;
pub mod polymer_system_builder;
pub mod trajectory;
pub mod trajectory_scanner;
pub mod types;
mod units;

mod analysis;

#[cfg(feature = "max_bonds_4")]
pub const MAX_BONDS: usize = 4;

#[cfg(feature = "max_bonds_5")]
pub const MAX_BONDS: usize = 5;

#[cfg(feature = "max_bonds_6")]
pub const MAX_BONDS: usize = 6;

const ATOMIC_MASS: [f64; 30] = [
    1.008,        // H
    4.002602,     // He
    6.94,         // Li
    9.0121831,    // Be
    10.81,        // B
    12.011,       // C
    14.007,       // N
    15.999,       // O
    18.998403163, // F
    20.1797,      // Ne
    22.98976928,  // Na
    24.305,       // Mg
    26.9815384,   // Al
    28.085,       // Si
    30.973761998, // P
    32.06,        // S
    35.45,        // Cl
    39.95,        // Ar
    39.0983,      // K
    40.078,       // Ca
    44.955907,    // Sc
    47.867,       // Ti
    50.9415,      // V
    51.9961,      // Cr
    54.938043,    // Mn
    55.845,       // Fe
    58.933194,    // Co
    58.6934,      // Ni
    63.546,       // Cu
    65.38,        // Zn
];

//pub use label_util::*;
//pub use polymer_system::*;
//pub use trajectory::*;

#[cfg(feature = "default_idx_u32")]
pub type DefaultIdx = u32;

#[cfg(feature = "default_idx_u64")]
pub type DefaultIdx = u64;

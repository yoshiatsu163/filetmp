use itertools::Itertools;
use nalgebra::{Matrix3, Point3, Vector3, center, distance, distance_squared};
use rustc_hash::FxHashMap;

use uom::si::f64::*;
use uom::si::{
    force::piconewton, length::nanometer, mass::dalton, mass_density::gram_per_cubic_centimeter,
    time::nanosecond, volume::cubic_nanometer,
};

use crate::DefaultIdx;
use crate::polymer_system::*;
use crate::polymer_system_builder::*;
use crate::trajectory::*;
use crate::types::{
    bounding_box::BoundingBox,
    label_util::{NameEncoder, StructureKind, SubStructure},
    util::{AtomProperty, Bond},
    vector_3d_data::{Forces, R3Set, Velocities},
};
use crate::units::util::*;
use crate::units::velocity::nanometer_per_nanosecond;

impl PolymerSystem {
    pub fn volume(&self) -> f64 {
        let bbox = self.bbox().as_matrix();
        bbox.determinant().abs()
    }

    pub fn volume_with_unit(&self) -> Volume {
        Volume::new::<cubic_nanometer>(self.volume())
    }

    pub fn system_mass(&self) -> f64 {
        self.views()
            .map(|atom| atom.mass())
            .reduce(|_, p| p)
            .unwrap_or(0.0)
    }

    pub fn system_mass_with_unit(&self) -> Mass {
        Mass::new::<dalton>(self.system_mass())
    }

    pub fn mass_density(&self) -> f64 {
        self.system_mass() / self.volume()
    }

    pub fn mass_density_with_unit(&self) -> MassDensity {
        MassDensity::new::<gram_per_cubic_centimeter>(self.mass_density())
    }

    pub fn center_of_mass<T, I>(&self, atom_indices: T) -> Point3<f64>
    where
        T: Iterator<Item = I>,
        I: Copy + Into<DefaultIdx>,
    {
        let com = self
            .views_with(atom_indices)
            .map(|atom| atom.mass() * atom.position())
            .reduce(|_, p| p);
        match com {
            Some(com) => Point3::new(com.x, com.y, com.z),
            None => panic!("No atom in the substructure"),
        }
    }

    pub fn center_of_mass_of(&self, substructure: &SubStructure) -> Point3<f64> {
        self.center_of_mass(self.atoms_under(substructure).into_iter())
    }

    pub fn center_of_geometry<T, I>(&self, atom_indices: T) -> Point3<f64>
    where
        T: Iterator<Item = I>,
        I: Copy + Into<DefaultIdx>,
    {
        let com = self
            .views_with(atom_indices)
            .map(|atom| *atom.position())
            .reduce(|_, p| p);
        match com {
            Some(com) => Point3::new(com.x, com.y, com.z),
            None => panic!("No atom in the substructure"),
        }
    }

    pub fn center_of_geometry_of(&self, substructure: &SubStructure) -> Point3<f64> {
        self.center_of_geometry(self.atoms_under(substructure).into_iter())
    }

    pub fn rg2<T, I>(&self, atom_indices: T) -> f64
    where
        T: Iterator<Item = I> + Clone,
        I: Copy + Into<DefaultIdx>,
    {
        let com = self.center_of_mass(atom_indices.clone());
        let rg2 = self
            .views_with(atom_indices)
            .map(|atom| {
                let r = atom.position() - com;
                r.x * r.x + r.y * r.y + r.z * r.z
            })
            .reduce(|_, p| p);
        match rg2 {
            Some(rg2) => rg2,
            None => panic!("No atom in the substructure"),
        }
    }

    pub fn rg2_of(&self, polymer: &SubStructure) -> f64 {
        self.rg2(self.atoms_under(polymer).into_iter())
    }

    pub fn distance_squared(&self, atom1: DefaultIdx, atom2: DefaultIdx) -> f64 {
        let a1 = self.position(atom1);
        let a2 = self.position(atom2);
        distance_squared(a1, a2)
    }

    pub fn distance(&self, atom1: DefaultIdx, atom2: DefaultIdx) -> f64 {
        self.distance_squared(atom1, atom2).sqrt()
    }

    pub fn e2e_vector(&self, polymer: &SubStructure) -> Vector3<f64> {
        if polymer.kind() != StructureKind::Polymer {
            panic!("e2e_vector is only for polymer, found {:?}", polymer);
        }

        let mut terminals = self
            .views_under(polymer)
            .filter(|atom| atom.is_backbone_terminal());
        let one_side = terminals.next().unwrap();
        let other = terminals.next().unwrap();
        assert!(terminals.next().is_none());

        one_side.position() - other.position()
    }
    // TODO
    // 部分鎖を与える関数
    // モノマーの並び順を与える関数
    // node weightのatomのイテレーター
    // e2e, RS
    // infer_polymer
    // infer_monomer
}

//! Time–series utilities: cross‑covariance/correlation and mean‑square displacement (MSD)
//!
//! The API is intentionally minimal: plain `&[f64]` (or `DVector`) in, `Vec<f64>` out.
//! Latencies are expressed as non‑negative integer lags `τ ∈ [0, max_lag]`.
//!
//! Two implementations are provided for each quantity:
//! * **naive** O(n²) – straightforward double loop, easy to read/debug.
//! * **fft**   O(n log n) – uses convolution via RustFFT for large signals.
//!
//! All "fft" functions produce results identical to the naive versions up to
//! numerical precision: the test‐suite asserts an L∞ error < 1e‑9 for random
//! inputs.  Call‑sites may optionally pass pre‑computed means/variances to avoid
//! recomputation in batch workflows.
//!
//! ```
//! use time_series::{cross_covariance_fft, cross_correlation_naive, msd_fft};
//! let x = (0..1024).map(|i| (2.0 * std::f64::consts::PI * (i as f64) / 25.0).sin()).collect::<Vec<_>>();
//! let y = (0..1024).map(|i| (2.0 * std::f64::consts::PI * ((i+7) as f64) / 25.0).sin()).collect::<Vec<_>>();
//! let c_xy = cross_covariance_fft(&x, &y, 128, None, None).unwrap();
//! println!("cov(τ=7) ≈ {}", c_xy[7]);
//! ```

use std::char::MAX;
use std::cmp::max_by;

use itertools::Itertools;
use nalgebra::{DVector, Matrix3, Point3, Vector3, center, distance, distance_squared};

use crate::DefaultIdx;
use crate::polymer_system::*;
use crate::polymer_system_builder::*;
use crate::trajectory::*;
use crate::types::{
    bounding_box::BoundingBox,
    label_util::{NameEncoder, StructureKind, SubStructure},
    util::{AtomProperty, Bond},
    vector_3d_data::{Forces, R3Set, Velocities},
};

use rustfft::{FftPlanner, num_complex::Complex};

/// Helper: mean and (optionally) variance of a slice.
fn mean_var(data: &[f64], compute_var: bool) -> (f64, Option<f64>) {
    let n_inv = 1.0 / data.len() as f64;
    let mean = data.iter().sum::<f64>() * n_inv;
    if compute_var {
        let var = data.iter().map(|&x| (x - mean).powi(2)).sum::<f64>() * n_inv;
        (mean, Some(var))
    } else {
        (mean, None)
    }
}

fn mean_var_vec3(data: &[Vector3<f64>], compute_var: bool) -> (Vector3<f64>, Option<f64>) {
    let n_inv = 1.0 / data.len() as f64;
    let mean = data.iter().map(|&v| v).sum::<Vector3<f64>>() * n_inv;
    if compute_var {
        let var = data.iter().map(|&v| (v - mean).norm_squared()).sum::<f64>() * n_inv;
        (mean, Some(var))
    } else {
        (mean, None)
    }
}

/// Next power‑of‑two ≥ `n` (minimum 1)
fn next_pow2(mut n: usize) -> usize {
    if n == 0 {
        return 1;
    }
    n -= 1;
    n |= n >> 1;
    n |= n >> 2;
    n |= n >> 4;
    n |= n >> 8;
    n |= n >> 16;
    #[cfg(target_pointer_width = "64")]
    {
        n |= n >> 32;
    }
    n + 1
}

/* =====================================================================
                      1‑D  cross‑covariance
===================================================================== */

/// Naive O(n²) cross‑covariance for non‑negative lags.
pub fn cross_covariance_naive<T, U>(
    x: T,
    y: U,
    max_lag: usize,
    mean_x: Option<f64>,
    mean_y: Option<f64>,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[f64]>,
    U: AsRef<[f64]>,
{
    let xs = x.as_ref();
    let ys = y.as_ref();
    if xs.len() == 0 || ys.len() == 0 {
        return Err("x and y must have the same length");
    }
    if xs.len() != ys.len() {
        return Err("x and y must have the same length");
    }
    if max_lag > xs.len() {
        return Err("max_lag exceeds sequence length");
    }

    let n = xs.len();
    let mx = mean_x.unwrap_or_else(|| mean_var(xs, false).0);
    let my = mean_y.unwrap_or_else(|| mean_var(ys, false).0);

    let mut cov = vec![0.0; max_lag + 1];
    for tau in 0..=max_lag {
        let mut acc = 0.0;
        for i in 0..(n - tau) {
            acc += (xs[i] - mx) * (ys[i + tau] - my);
        }
        cov[tau] = acc / (n - tau) as f64;
    }
    Ok(cov)
}

/// FFT‑based O(n log n) cross‑covariance (non‑negative lags).
pub fn cross_covariance_fft<T, U>(
    x: T,
    y: U,
    max_lag: usize,
    mean_x: Option<f64>,
    mean_y: Option<f64>,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[f64]>,
    U: AsRef<[f64]>,
{
    let xs = x.as_ref();
    let ys = y.as_ref();
    if xs.len() == 0 || ys.len() == 0 {
        return Err("x and y must have the same length");
    }
    if xs.len() != ys.len() {
        return Err("x and y must have the same length");
    }
    if max_lag > xs.len() {
        return Err("max_lag exceeds sequence length");
    }

    let n = xs.len();
    let mx = mean_x.unwrap_or_else(|| mean_var(xs, false).0);
    let my = mean_y.unwrap_or_else(|| mean_var(ys, false).0);

    // Demean and zero‑pad both sequences to length ≥ 2n.
    let m = next_pow2(2 * n);
    let mut a: Vec<Complex<f64>> = vec![Complex::from(0.0); m];
    let mut b: Vec<Complex<f64>> = vec![Complex::from(0.0); m];

    for (i, &val) in xs.iter().enumerate() {
        a[i].re = val - mx;
    }
    // Reverse y for correlation.
    for (i, &val) in ys.iter().enumerate() {
        b[i].re = val - my;
    }

    let mut planner = FftPlanner::new();
    let fft = planner.plan_fft_forward(m);
    fft.process(&mut a);
    fft.process(&mut b);

    for (ai, bi) in std::iter::zip(a.iter_mut(), b.iter()) {
        *ai *= bi.conj();
    }
    let ifft = planner.plan_fft_inverse(m);
    ifft.process(&mut a);

    // Normalisation: rustfft's inverse is unscaled
    let scale = 1.0 / m as f64;
    let mut cov = Vec::with_capacity(max_lag + 1);
    for tau in 0..=max_lag {
        cov.push(a[tau].re * scale / (n - tau) as f64);
    }
    Ok(cov)
}

/* =====================================================================
                      1‑D  cross‑correlation
===================================================================== */

pub fn cross_correlation_naive<T, U>(
    x: T,
    y: U,
    max_lag: usize,
    mean_x: Option<f64>,
    mean_y: Option<f64>,
    var_x: Option<f64>,
    var_y: Option<f64>,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[f64]>,
    U: AsRef<[f64]>,
{
    let cov = cross_covariance_naive(&x, &y, max_lag, mean_x, mean_y)?;
    let xs = x.as_ref();
    let ys = y.as_ref();
    let vx = var_x.unwrap_or_else(|| mean_var(xs, true).1.unwrap());
    let vy = var_y.unwrap_or_else(|| mean_var(ys, true).1.unwrap());
    let denom = (vx.sqrt() * vy.sqrt()).max(std::f64::EPSILON);
    Ok(cov.into_iter().map(|c| c / denom).collect())
}

pub fn cross_correlation_fft<T, U>(
    x: T,
    y: U,
    max_lag: usize,
    mean_x: Option<f64>,
    mean_y: Option<f64>,
    var_x: Option<f64>,
    var_y: Option<f64>,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[f64]>,
    U: AsRef<[f64]>,
{
    let cov = cross_covariance_fft(&x, &y, max_lag, mean_x, mean_y)?;
    let xs = x.as_ref();
    let ys = y.as_ref();
    let vx = var_x.unwrap_or_else(|| mean_var(xs, true).1.unwrap());
    let vy = var_y.unwrap_or_else(|| mean_var(ys, true).1.unwrap());
    let denom = (vx.sqrt() * vy.sqrt()).max(std::f64::EPSILON);
    Ok(cov.into_iter().map(|c| c / denom).collect())
}

/* =====================================================================
                      1‑D  mean‑square displacement
===================================================================== */

pub fn msd_naive<T>(data: T, max_lag: usize) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[f64]>,
{
    let xs = data.as_ref();
    if max_lag > xs.len() {
        return Err("max_lag exceeds length");
    }
    if xs.len() == 0 {
        return Err("data must have at least one element");
    }

    let n = xs.len();
    let mut msd = vec![0.0; max_lag + 1];
    for tau in 0..=max_lag {
        let mut acc = 0.0;
        for i in 0..(n - tau) {
            let d = xs[i + tau] - xs[i];
            acc += d * d;
        }
        msd[tau] = acc / (n - tau) as f64;
    }

    Ok(msd)
}

pub fn msd_fft<T>(data: T, max_lag: usize) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[f64]>,
{
    let xs = data.as_ref();
    if max_lag > xs.len() {
        return Err("max_lag exceeds length");
    }
    if xs.len() == 0 {
        return Err("data must have at least one element");
    }

    // msd(τ) = <x(t+τ)^2 - x(t)^2>
    //        = <x(t)^2> + <x(t+τ)^2> -2<x(t)x(t+τ)>
    // (N-τ)⋅msd(τ) = sum(x[t+τ]^2 for t in 0..N-τ)
    //                  + sum(x[t]^2 for t in 0..N-τ)
    //                  - 2*sum(x[t]*x[t+τ] for t in 0..N-τ)
    //              = 2sum(x[t]^2 for t in 0..N)
    //                  - sum(x[t]^2 for t in 0..τ)
    //                  - sum(x[t]^2 for t in N-τ..N)
    //                  - 2 * autocovariance(τ)
    let mx = mean_var(xs, false).0;
    let xs_dm: Vec<f64> = xs.iter().map(|&v| v - mx).collect();
    let sum2d = 2.0 * xs_dm.iter().map(|&v| v * v).sum::<f64>();
    let autocov = cross_covariance_fft(&xs_dm, &xs_dm, max_lag, Some(0.0), Some(0.0))?;

    let n = xs_dm.len();
    let mut front_sum = 0.0;
    let mut back_sum = 0.0;
    let mut msd = vec![0.0; max_lag + 1];
    for tau in 1..=max_lag {
        let scale = 1.0 / (n - tau) as f64;
        front_sum += xs_dm[tau - 1] * xs_dm[tau - 1];
        back_sum += xs_dm[n - tau] * xs_dm[n - tau];
        msd[tau] = (sum2d - front_sum - back_sum) * scale - 2.0 * autocov[tau];
    }
    msd[0] = sum2d * (1.0 / n as f64) - 2.0 * autocov[0];
    Ok(msd)
}

/* =====================================================================
                      3‑D  convenience wrappers
===================================================================== */

pub fn cross_covariance_vec3_naive<T, U>(
    v1: T,
    v2: U,
    max_lag: usize,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[Vector3<f64>]>,
    U: AsRef<[Vector3<f64>]>,
{
    let v1 = v1.as_ref();
    let v2 = v2.as_ref();
    if v1.len() != v2.len() {
        return Err("inputs must have same length");
    }
    if v1.len() == 0 || v2.len() == 0 {
        return Err("data must have at least one element");
    }
    if max_lag > v1.len() {
        return Err("max_lag must be less than or equal to input length");
    }

    let m1 = mean_var_vec3(v1, false).0;
    let m2 = mean_var_vec3(v2, false).0;

    let n = v1.len();
    let mut cov = vec![0.0; max_lag + 1];
    for tau in 0..=max_lag {
        let mut acc = 0.0;
        for i in 0..n - tau {
            acc += (v1[i] - m1).dot(&(v2[i + tau] - m2));
        }
        cov[tau] = acc / (n - tau) as f64;
    }
    Ok(cov)
}

pub fn cross_covariance_vec3_fft<T, U>(
    v1: T,
    v2: U,
    max_lag: usize,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[Vector3<f64>]>,
    U: AsRef<[Vector3<f64>]>,
{
    let v1 = v1.as_ref();
    let v2 = v2.as_ref();
    if v1.len() != v2.len() {
        return Err("inputs must have same length");
    }
    if v1.len() == 0 || v2.len() == 0 {
        return Err("data must have at least one element");
    }
    if max_lag > v1.len() {
        return Err("max_lag must be less than or equal to input length");
    }

    let mut cov = vec![0.0; max_lag + 1];
    for dim in 0..3 {
        let m1 = v1.iter().map(|v| v[dim]).sum::<f64>() / v1.len() as f64;
        let m2 = v2.iter().map(|v| v[dim]).sum::<f64>() / v2.len() as f64;
        let cc = cross_covariance_fft(
            v1.iter().map(|v| v[dim]).collect::<Vec<f64>>(),
            v2.iter().map(|v| v[dim]).collect::<Vec<f64>>(),
            max_lag,
            Some(m1),
            Some(m2),
        )?;
        assert_eq!(cov.len(), cc.len());
        for (i, &c) in cc.iter().enumerate() {
            cov[i] += c;
        }
    }
    Ok(cov)
}

pub fn cross_correlation_vec3_naive<T, U>(
    v1: T,
    v2: U,
    max_lag: usize,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[Vector3<f64>]>,
    U: AsRef<[Vector3<f64>]>,
{
    let v1 = v1.as_ref();
    let v2 = v2.as_ref();
    if v1.len() != v2.len() {
        return Err("inputs must have same length");
    }
    if v1.len() == 0 || v2.len() == 0 {
        return Err("data must have at least one element");
    }
    if max_lag > v1.len() {
        return Err("max_lag must be less than or equal to input length");
    }

    let (m1, var1) = mean_var_vec3(v1, true);
    let (m2, var2) = mean_var_vec3(v2, true);
    let var1_inv_sqrt = 1.0 / var1.unwrap().sqrt();
    let var2_inv_sqrt = 1.0 / var2.unwrap().sqrt();

    let n = v1.len();
    let mut cov = vec![0.0; max_lag + 1];
    for tau in 0..=max_lag {
        let mut acc = 0.0;
        for i in 0..n - tau {
            acc += (v1[i] - m1).dot(&(v2[i + tau] - m2)) * var1_inv_sqrt * var2_inv_sqrt;
        }
        cov[tau] = acc / (n - tau) as f64;
    }
    Ok(cov)
}

pub fn cross_correlation_vec3_fft<T, U>(
    v1: T,
    v2: U,
    max_lag: usize,
) -> Result<Vec<f64>, &'static str>
where
    T: AsRef<[Vector3<f64>]>,
    U: AsRef<[Vector3<f64>]>,
{
    let v1 = v1.as_ref();
    let v2 = v2.as_ref();
    if v1.len() != v2.len() {
        return Err("inputs must have same length");
    }
    if v1.len() == 0 || v2.len() == 0 {
        return Err("data must have at least one element");
    }
    if max_lag > v1.len() {
        return Err("max_lag must be less than or equal to input length");
    }

    let mut cor = vec![0.0; max_lag + 1];
    for dim in 0..3 {
        let m1 = v1.iter().map(|v| v[dim]).sum::<f64>() / v1.len() as f64;
        let m2 = v2.iter().map(|v| v[dim]).sum::<f64>() / v2.len() as f64;
        let var1 = v1.iter().map(|v| (v[dim] - m1).powi(2)).sum::<f64>() / v1.len() as f64;
        let var2 = v2.iter().map(|v| (v[dim] - m2).powi(2)).sum::<f64>() / v2.len() as f64;
        let cc = cross_correlation_fft(
            v1.iter().map(|v| v[dim]).collect::<Vec<f64>>(),
            v2.iter().map(|v| v[dim]).collect::<Vec<f64>>(),
            max_lag,
            Some(m1),
            Some(m2),
            Some(var1),
            Some(var2),
        )?;
        assert_eq!(cor.len(), cc.len());
        for (i, &c) in cc.iter().enumerate() {
            cor[i] += c;
        }
    }
    Ok(cor)
}

#[cfg(test)]
mod test {
    use super::*;
    use rand::rngs::StdRng;
    use rand::{Rng, SeedableRng};
    use rand_distr::StandardNormal;

    fn assert_abs_diff_eq(a: f64, b: f64, eps: f64) -> Result<(), String> {
        if (a - b).abs() < eps {
            return Ok(());
        }
        let mut msg = format!("Assertion failed: {} != {}\n", a, b);
        msg += format!("  |a - b| = {}\n", (a - b).abs()).as_str();
        Err(msg)
    }

    /* =====================================================================
                        AR1 model for auto cor/cov
    ===================================================================== */

    #[derive(Debug, Clone, Copy)]
    struct AR1 {
        seed: u64,
        length: usize,
        phi: f64,
        sigma2: f64,
    }

    fn generate_ar1(param: AR1) -> Vec<f64> {
        let (seed, n, phi, sigma2) = (param.seed, param.length, param.phi, param.sigma2);
        let mut rng = StdRng::seed_from_u64(seed);
        let sigma = sigma2.sqrt();
        let mut x = vec![0.0; n];
        for i in 1..n {
            let rnd: f64 = rng.sample(StandardNormal);
            x[i] = phi * x[i - 1] + rnd * sigma;
        }
        x
    }

    fn theoretical_ar1_autocov(max_lag: usize, param: AR1) -> Vec<f64> {
        let (phi, sigma2) = (param.phi, param.sigma2);
        let mut cov = vec![0.0; max_lag + 1];
        for tau in 0..=max_lag {
            cov[tau] = sigma2 * phi.powi(tau as i32) / (1.0 - phi * phi);
        }
        cov
    }

    fn theoretical_ar1_autocor(max_lag: usize, param: AR1) -> Vec<f64> {
        let phi = param.phi;
        let mut cor = vec![0.0; max_lag + 1];
        for tau in 0..=max_lag {
            cor[tau] = phi.powi(tau as i32);
        }
        cor
    }

    #[test]
    fn test_ar1_auto() {
        let param = AR1 {
            seed: 123456,
            length: 1048576,
            phi: 0.8,
            sigma2: 1.0,
        };
        let max_lag = 20;
        let x = generate_ar1(param);

        let tcov = theoretical_ar1_autocov(max_lag, param);
        let tcor = theoretical_ar1_autocor(max_lag, param);
        let cov_n = cross_covariance_naive(&x, &x, max_lag, None, None).unwrap();
        let cov_f = cross_covariance_fft(&x, &x, max_lag, None, None).unwrap();
        let cor_n = cross_correlation_naive(&x, &x, max_lag, None, None, None, None).unwrap();
        let cor_f = cross_correlation_fft(&x, &x, max_lag, None, None, None, None).unwrap();

        //for tau in 0..=max_lag {
        //    //println!("({}, {}),", tcov[tau], cov_n[tau]);
        //    //println!("({}, {}),", cov_n[tau], cov_f[tau]);
        //    println!("({}, {}),", tcor[tau], cor_n[tau]);
        //}

        // MAE between theoretical and naive autocov
        let mae_cov = (0..=max_lag)
            .into_iter()
            .map(|tau| (tcov[tau] - cov_n[tau]).abs())
            .sum::<f64>()
            / (max_lag + 1) as f64;
        assert_abs_diff_eq(mae_cov, 0.0, 0.01).unwrap();

        // MAE between theoretical and naive autocor
        let mar_cor = (0..=max_lag)
            .into_iter()
            .map(|tau| (tcor[tau] - cor_n[tau]).abs())
            .sum::<f64>()
            / (max_lag + 1) as f64;
        assert_abs_diff_eq(mar_cor, 0.0, 0.002).unwrap();

        for tau in 0..=max_lag {
            assert_abs_diff_eq(cov_n[tau], cov_f[tau], 1e-9).unwrap();
            assert_abs_diff_eq(cor_n[tau], cor_f[tau], 1e-9).unwrap();
        }
    }

    // TODO: test for 3D wrapper

    #[test]
    fn test_msd_1d() {
        let param = AR1 {
            seed: 12345,
            length: 4194304,
            phi: 1.0,
            sigma2: 1.0,
        };
        let max_lag = 50;
        let x = generate_ar1(param);

        let tmsd = (0..=max_lag).map(|x| x as f64).collect_vec();
        let msd_n = msd_naive(&x, max_lag).unwrap();
        let msd_f = msd_fft(&x, max_lag).unwrap();

        //for tau in 0..=max_lag {
        //    //println!("({}, {}),", tmsd[tau], msd_n[tau]);
        //    println!("({}, {}),", msd_n[tau], msd_f[tau]);
        //}

        let mae = (0..=max_lag)
            .map(|tau| (tmsd[tau] - msd_n[tau]).abs())
            .sum::<f64>()
            / (max_lag + 1) as f64;
        assert_abs_diff_eq(mae, 0.0, 0.01).unwrap();

        for tau in 0..=max_lag {
            assert_abs_diff_eq(msd_n[tau], msd_f[tau], 1e-6).unwrap();
        }
    }
}

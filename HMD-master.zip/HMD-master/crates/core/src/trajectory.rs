use std::ffi::OsStr;
use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Read, Write};
use std::path::PathBuf;
use std::process::exit;

use byteorder::{ByteOrder, LittleEndian};
use nalgebra::Point3;
use serde::{Deserialize, Serialize};
use serde_json::{self};
use twox_hash::XxHash3_128;

use crate::polymer_system::*;
use crate::polymer_system_builder::*;
use crate::types::{
    bounding_box::BoundingBox,
    label_util::{NameEncoder, StructureKind, SubStructure},
    util::{AtomProperty, Bond},
    vector_3d_data::{Forces, R3Set, Velocities},
};

#[derive(Serialize, Deserialize)]
struct MetaData {
    version: usize,
    description: String,
    snapshot_type: SnapshotType,
    nframes: usize,
    natoms: usize,
    nbonds: usize,
    npolymers: usize,
    nmonomers: usize,
    ncrosslinks: usize,
    structure_names: Vec<String>,
    encoded_structure_names: Vec<u8>,
    has_velocity: bool,
    has_force: bool,
}

#[derive(Serialize, Deserialize, Clone, Debug, Eq, PartialEq, Copy)]
pub enum SnapshotType {
    Binary,
    Text,
}

impl SnapshotType {
    fn from_str(s: &str) -> Self {
        match s {
            "Binary" => Self::Binary,
            "Text" => Self::Text,
            _ => {
                eprintln!("invalid snapshot type: {}", s);
                exit(1);
            }
        }
    }

    fn to_str(&self) -> &str {
        match self {
            Self::Binary => "Binary",
            Self::Text => "Text",
        }
    }
}

const DEFAULT_BUFFER_CAPACITY: usize = 512; // 512 kiB

const METADATA_PATH: &str = "metadata.json";
const TIME_BOX_PATH: &str = "time_timestep_bbox.csv";
const STRUCTURE_PATH: &str = "sub_structures.csv";
const BONDLIST_PATH: &str = "bondlist.csv";
const POSITION_DIR: &str = "positions";
const VELOCITY_DIR: &str = "velocities";
const FORCE_DIR: &str = "forces";
const TIME_BOX_HEADER: [&str; 14] = [
    "timestep",
    "time",
    "box_origin_x",
    "box_origin_y",
    "box_origin_z",
    "box_avec_x",
    "box_avec_y",
    "box_avec_z",
    "box_bvec_x",
    "box_bvec_y",
    "box_bvec_z",
    "box_cvec_x",
    "box_cvec_y",
    "box_cvec_z",
];
const STRUCTURE_HEADER: [&str; 10] = [
    "atom_idx",
    "atomic_number",
    "polymer_name",
    "polymer_idx",
    "monomer_name",
    "monomer_idx",
    "crosslink_name",
    "crosslink_idx",
    "atom_property",
    "nbonds",
];
const BONDLIST_HEADER: [&str; 3] = ["head", "tail", "bond_order"];

const HASH_SIZE: usize = 16; // 16 bytes

#[derive(Debug, Clone, PartialEq, Eq)]
enum FileState {
    Uncompressed(PathBuf),
    Compressed(PathBuf),
    BothNotFound(PathBuf),
}

fn is_zstd_compressed(path: PathBuf) -> FileState {
    // 非圧縮パスしか渡されない仕様
    assert!(path.extension().is_none() || path.extension() != Some(OsStr::new("zst")));
    let zst = {
        let zst = path.to_str().unwrap().to_string() + ".zst";
        PathBuf::from(zst)
    };

    let un_compressed_exists = path.exists();
    let zst_exists = zst.exists();
    if un_compressed_exists && !zst_exists {
        return FileState::Uncompressed(path);
    } else if !un_compressed_exists && zst_exists {
        return FileState::Compressed(zst);
    } else if !un_compressed_exists && !zst_exists {
        return FileState::BothNotFound(path);
    } else {
        panic!("both compressed and uncompressed files exist");
    }
}

// TODO: replace panics with better Error types
// Currently, unwraps when file content is broken
fn get_file_content(path: PathBuf) -> std::io::Result<String> {
    match is_zstd_compressed(path) {
        FileState::Uncompressed(path) => std::fs::read_to_string(path),
        FileState::Compressed(path) => {
            let file = File::open(path)?;
            let decompressed = zstd::stream::decode_all(file).unwrap();
            Ok(String::from_utf8(decompressed).unwrap())
        }
        FileState::BothNotFound(path) => {
            panic!(
                "both compressed and uncompressed files not found. path: {}",
                path.display()
            );
        }
    }
}

fn path_with_root(root: PathBuf, path: PathBuf) -> PathBuf {
    if path.is_absolute() {
        return path;
    }
    root.join(path)
}

pub struct Trajectory {
    root: PathBuf,
    probe: PolymerSystem,
    nframes: usize,
    current_frame: usize, // None just after created
    is_initiated: bool,

    snapshot_type: SnapshotType,
    has_velocity: bool,
    has_force: bool,

    buffer: Vec<u8>,           // io buffer for position, velocity, and force
    text_buffer: Vec<Vec<u8>>, // io buffer for text data

    // 小さいデータはオンメモリに保持
    times: Vec<f64>,
    timesteps: Vec<usize>,
    bounding_boxes: Vec<BoundingBox>,
    //_phantom: PhantomData<fn() -> Mode>,
}

impl Trajectory {
    fn metadata_path(&self) -> PathBuf {
        self.root.clone().join(METADATA_PATH)
    }

    fn time_box_path(&self) -> PathBuf {
        self.root.clone().join(TIME_BOX_PATH)
    }

    fn substructure_path(&self) -> PathBuf {
        self.root.clone().join(STRUCTURE_PATH)
    }

    fn bondlist_path(&self) -> PathBuf {
        self.root.clone().join(BONDLIST_PATH)
    }

    fn position_dir(&self) -> PathBuf {
        self.root.clone().join(POSITION_DIR)
    }

    fn velocity_dir(&self) -> PathBuf {
        self.root.clone().join(VELOCITY_DIR)
    }

    fn force_dir(&self) -> PathBuf {
        self.root.clone().join(FORCE_DIR)
    }

    fn position_snapshot_path(&self, frame: usize) -> PathBuf {
        self.position_dir().join(frame.to_string())
    }

    fn velocity_snapshot_path(&self, frame: usize) -> PathBuf {
        self.velocity_dir().join(frame.to_string())
    }

    fn force_snapshot_path(&self, frame: usize) -> PathBuf {
        self.force_dir().join(frame.to_string())
    }

    pub fn nframes(&self) -> usize {
        self.nframes
    }

    pub fn current_frame(&self) -> usize {
        self.current_frame
    }

    pub fn times(&self) -> &[f64] {
        &self.times
    }

    pub fn timesteps(&self) -> &[usize] {
        &self.timesteps
    }

    pub fn bounding_boxes(&self) -> &[BoundingBox] {
        &self.bounding_boxes
    }

    pub fn has_velocity(&self) -> bool {
        self.has_velocity
    }

    pub fn has_force(&self) -> bool {
        self.has_force
    }

    pub fn probe(&self) -> Option<&PolymerSystem> {
        if self.is_initiated {
            Some(&self.probe)
        } else {
            None
        }
    }

    pub fn probe_mut(&mut self) -> Option<&mut PolymerSystem> {
        if self.is_initiated {
            Some(&mut self.probe)
        } else {
            None
        }
    }

    pub fn create(
        root: PathBuf,
        init: PolymerSystem,
        nframes: usize,
        snapshot_type: SnapshotType,
    ) -> Self {
        let mut times = vec![0.0; nframes];
        let mut timesteps = vec![0; nframes];
        let mut bounding_boxes = vec![BoundingBox::default(); nframes];
        let natoms = init.natoms();
        let has_velocity = init.has_velocity();
        let has_force = init.has_force();
        times[0] = init.time();
        timesteps[0] = init.timestep();
        bounding_boxes[0] = init.bbox().clone();
        let traj = Trajectory {
            root: root.clone(),
            probe: init,
            nframes,
            current_frame: 0,
            is_initiated: false,

            snapshot_type: snapshot_type.clone(),
            buffer: vec![0; 4 * 3 * natoms + HASH_SIZE], // f32 = 4 bytes
            text_buffer: vec![Vec::with_capacity(128); natoms],
            has_velocity,
            has_force,

            // 小さいデータはオンメモリに保持
            times,
            timesteps,
            bounding_boxes,
        };

        // create directory
        if !root.parent().unwrap().exists() {
            panic!(
                "parent directory {} is not found",
                root.parent().unwrap().display()
            );
        }
        if root.exists() {
            println!(
                "warning: root directory {} already exists. It will be overwritten",
                root.display()
            );
            // remove all items in the root directory
            std::fs::remove_dir_all(&root).expect("failed to remove existing directory");
        }
        std::fs::create_dir(&root).expect("failed to create root directory");

        // metadata
        let (name_codes, structure_names) = traj
            .probe
            .name_encoder()
            .pairs()
            .map(|(code, name)| (code.to_u8(), name.to_owned()))
            .unzip();
        let meta = MetaData {
            version: 1,
            description: "test".to_string(),
            snapshot_type,
            nframes,
            natoms: traj.probe.natoms(),
            nbonds: traj.probe.nbonds(),
            npolymers: traj.probe.all_polymers().count(),
            nmonomers: traj.probe.all_monomers().count(),
            ncrosslinks: traj.probe.all_crosslinks().count(),
            structure_names,
            encoded_structure_names: name_codes,
            has_velocity: traj.probe.has_velocity(),
            has_force: traj.probe.has_force(),
        };
        let meta_json = serde_json::to_string(&meta).unwrap();
        std::fs::write(traj.metadata_path(), meta_json).expect("failed to write metadata.json");

        // time, timesteps, and bounding boxes
        // just create empty file for now
        // data will be written when closing the trajectory
        std::fs::write(
            traj.time_box_path(),
            TIME_BOX_HEADER.join(",").to_owned() + "\n",
        )
        .expect("failed to write time_timestep_bbox.csv");

        // create structure csv file and write data
        {
            fn stringify(label: Option<&SubStructure>) -> (String, String) {
                match label {
                    Some(l) => (l.name().to_u8().to_string(), l.index().to_string()),
                    None => ("".to_string(), "".to_string()),
                }
            }

            let mut bw = BufWriter::new(
                File::create(traj.substructure_path())
                    .expect("failed to create sub_structures.csv"),
            );
            let header = STRUCTURE_HEADER.join(",").to_owned() + "\n";
            bw.write(header.as_bytes()).unwrap();
            for atom in traj.probe.views() {
                let (pol_name, pol_idx) = stringify(atom.polymer_chain());
                let (monomer_name, monomer_idx) = stringify(atom.monomer());
                let (cross_name, cross_idx) = stringify(atom.crosslink());
                let line = format!(
                    "{},{},{},{},{},{},{},{},{},{}\n",
                    atom.index(),
                    atom.atomic_number(),
                    pol_name,
                    pol_idx,
                    monomer_name,
                    monomer_idx,
                    cross_name,
                    cross_idx,
                    atom.property().to_string(),
                    atom.neighbor_indices().count(),
                );
                bw.write(line.as_bytes()).unwrap();
            }
            bw.flush().expect("failed to write sub_structures.csv");
        }

        // bond list
        {
            let mut bw = BufWriter::new(
                File::create(traj.bondlist_path()).expect("failed to create bondlist.csv"),
            );
            let bonds = {
                let mut x = traj.probe.bond_iter().collect::<Vec<Bond>>();
                x.sort_by_key(|b| b.small);
                x
            };
            bw.write((BONDLIST_HEADER.join(",").to_owned() + "\n").as_bytes())
                .unwrap();
            for bond in bonds {
                let line = format!("{},{},{}\n", bond.small, bond.big, bond.order);
                bw.write(line.as_bytes()).unwrap();
            }
            bw.flush().expect("failed to write bondlist.csv");
        }

        // just create directory for snapshots
        assert!(!traj.position_dir().exists());
        assert!(!traj.velocity_dir().exists());
        assert!(!traj.force_dir().exists());
        std::fs::create_dir(&traj.position_dir()).expect("failed to create positions directory");
        if traj.probe.has_velocity() {
            std::fs::create_dir(traj.velocity_dir())
                .expect("failed to create velocities directory");
        }
        if traj.probe.has_force() {
            std::fs::create_dir(traj.force_dir()).expect("failed to create forces directory");
        }

        assert!(!traj.is_initiated);
        traj
    }

    pub fn from_file(traj_path: PathBuf) -> Self {
        if !traj_path.exists() {
            panic!("trajectory {} not found", traj_path.display());
        }

        let meta: MetaData = match is_zstd_compressed(traj_path.join(METADATA_PATH)) {
            FileState::Uncompressed(path) => {
                let file = File::open(path).unwrap();
                serde_json::from_reader(file).expect("failed to read metadata.json")
            }
            FileState::Compressed(path) => {
                let file = File::open(path).unwrap();
                let decoder = zstd::stream::Decoder::new(file).unwrap();
                serde_json::from_reader(decoder).expect("failed to read metadata.json")
            }
            FileState::BothNotFound(path) => {
                panic!(
                    "both compressed and uncompressed files not found. path: {}",
                    path_with_root(traj_path, path).display()
                );
            }
        };

        let mut traj = Trajectory {
            root: traj_path,
            probe: PolymerSystem::default(), // stub
            nframes: meta.nframes,
            current_frame: 0,
            is_initiated: false,
            snapshot_type: meta.snapshot_type,
            has_velocity: meta.has_velocity,
            has_force: meta.has_force,
            buffer: vec![0; 4 * 3 * meta.natoms + HASH_SIZE],
            text_buffer: vec![Vec::with_capacity(128); meta.natoms],
            times: vec![0.0; meta.nframes],
            timesteps: vec![0; meta.nframes],
            bounding_boxes: vec![BoundingBox::default(); meta.nframes],
        };

        // read time, timestep, and bounding box
        {
            let text = match get_file_content(traj.time_box_path()) {
                Ok(text) => text,
                Err(err) => {
                    panic!(
                        "Error while reading file {}. error:\n    {:?}",
                        traj.time_box_path().to_str().unwrap(),
                        err
                    );
                }
            };
            let header = text.lines().next().unwrap();
            assert_eq!(header.split(',').collect::<Vec<&str>>(), TIME_BOX_HEADER);

            let bboxes = &mut traj.bounding_boxes;
            let mut i = 0;
            for line in text.lines().skip(1) {
                let mut iter = line.split(',');
                let bbox = &mut bboxes[i];
                traj.timesteps[i] = iter.next().unwrap().parse::<usize>().unwrap();
                traj.times[i] = iter.next().unwrap().parse::<f64>().unwrap();
                bbox.set_origin_x(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_origin_y(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_origin_z(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_avec_x(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_avec_y(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_avec_z(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_bvec_x(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_bvec_y(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_bvec_z(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_cvec_x(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_cvec_y(iter.next().unwrap().parse::<f64>().unwrap());
                bbox.set_cvec_z(iter.next().unwrap().parse::<f64>().unwrap());
                assert!(iter.next().is_none());
                i += 1;
            }
            assert_eq!(i, meta.nframes);
        }

        let mut builder = PolymerSystemBuilder::new();
        builder.replace_name_encoder(NameEncoder::from_list(
            meta.encoded_structure_names,
            meta.structure_names,
        ));

        // structures
        let mut nbonds = vec![0; meta.natoms];
        {
            let text = match get_file_content(traj.substructure_path()) {
                Ok(text) => text,
                Err(err) => {
                    panic!(
                        "Error while reading file {}. error:\n    {:?}",
                        traj.substructure_path().to_str().unwrap(),
                        err
                    );
                }
            };
            let header = text.lines().next().unwrap();
            assert_eq!(header.split(',').collect::<Vec<&str>>(), STRUCTURE_HEADER);

            for (i, line) in text.lines().skip(1).enumerate() {
                let mut iter = line.split(',');

                let atom_idx = iter.next().unwrap().parse::<usize>().unwrap();
                let atomic_number = iter.next().unwrap().parse::<u8>().unwrap();
                let polymer_name = iter.next().unwrap();
                let polymer_idx = iter.next().unwrap();
                let monomer_name = iter.next().unwrap();
                let monomer_idx = iter.next().unwrap();
                let crosslink_name = iter.next().unwrap();
                let crosslink_idx = iter.next().unwrap();
                let atom_prop = iter.next().unwrap().parse::<AtomProperty>().unwrap();
                nbonds[i] = iter.next().unwrap().parse::<usize>().unwrap();
                assert!(iter.next().is_none());

                let mut atom = BuilderAtom::new(atom_idx, atomic_number, Point3::default());
                atom.property = atom_prop;
                builder.add_atom(atom).unwrap();

                if !polymer_name.is_empty() {
                    assert!(!polymer_idx.is_empty());
                    builder
                        .set_substructure(
                            atom_idx,
                            StructureKind::Polymer,
                            polymer_name,
                            polymer_idx.parse().unwrap(),
                        )
                        .unwrap();
                }
                if !monomer_name.is_empty() {
                    assert!(!monomer_idx.is_empty());
                    builder
                        .set_substructure(
                            atom_idx,
                            StructureKind::Monomer,
                            monomer_name,
                            monomer_idx.parse().unwrap(),
                        )
                        .unwrap();
                }
                if !crosslink_name.is_empty() {
                    assert!(!crosslink_idx.is_empty());
                    builder
                        .set_substructure(
                            atom_idx,
                            StructureKind::Crosslink,
                            crosslink_name,
                            crosslink_idx.parse().unwrap(),
                        )
                        .unwrap();
                }
                assert_eq!(i, atom_idx);
            }
        }

        let mut atoms = builder
            .atoms
            .iter()
            .filter(|(i, _)| **i < 250)
            .map(|(i, atom)| (*i, (*atom).clone()))
            .collect::<Vec<(usize, BuilderAtom)>>();
        atoms.sort_by_key(|(i, _)| *i);

        // bonds
        {
            let text = match get_file_content(traj.bondlist_path()) {
                Ok(text) => text,
                Err(err) => {
                    panic!(
                        "Error while reading file {}. error:\n    {:?}",
                        traj.bondlist_path().to_str().unwrap(),
                        err
                    );
                }
            };
            let header = text.lines().next().unwrap();
            assert_eq!(header.split(',').collect::<Vec<&str>>(), BONDLIST_HEADER);

            let mut n = 0;
            for line in text.lines().skip(1) {
                let mut iter = line.split(',');
                let head = iter.next().unwrap().parse::<usize>().unwrap();
                let tail = iter.next().unwrap().parse::<usize>().unwrap();
                let order = iter.next().unwrap().parse::<u8>().unwrap();
                assert!(iter.next().is_none());
                builder.add_bond(head, tail, order).unwrap();
                n += 1;
            }
            assert_eq!(n, meta.nbonds);
        }

        // position, velocity and force are stubs here
        // they will be read when each snapshot is loaded
        traj.probe = PolymerSystem::finalize(builder);
        if traj.has_velocity {
            traj.probe.swap_velocities(Velocities::new());
        }
        if traj.has_force {
            traj.probe.swap_forces(Forces::new());
        }

        assert!(!traj.is_initiated);
        traj
    }

    pub fn save(&self) {
        assert_eq!(self.times.len(), self.nframes);
        assert_eq!(self.timesteps.len(), self.nframes);
        assert_eq!(self.bounding_boxes.len(), self.nframes);

        // write small data
        let mut bw = {
            let file = File::create(&self.time_box_path())
                .expect(format!("failed to create {}", self.time_box_path().display()).as_str());
            BufWriter::new(file)
        };

        let header = TIME_BOX_HEADER.join(",").to_owned() + "\n";
        bw.write(header.as_bytes()).unwrap();
        for i in 0..self.nframes {
            let (time, timestep, bbox) =
                (self.times[i], self.timesteps[i], &self.bounding_boxes[i]);
            let line = format!(
                "{},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e}\n",
                timestep,
                time,
                bbox.origin().x,
                bbox.origin().y,
                bbox.origin().z,
                bbox.avec().x,
                bbox.avec().y,
                bbox.avec().z,
                bbox.bvec().x,
                bbox.bvec().y,
                bbox.bvec().z,
                bbox.cvec().x,
                bbox.cvec().y,
                bbox.cvec().z,
            );
            bw.write(line.as_bytes()).unwrap();
        }
        bw.flush().expect("failed to write time_timestep_bbox.csv");
    }

    fn write_array_binary<T: R3Set>(path: PathBuf, data: &T, buffer: &mut Vec<u8>) {
        let mut file = File::create(&path)
            .expect(format!("failed to create file {}", path.display()).as_str());

        let natoms = data.count();
        assert_eq!(buffer.len(), natoms * 3 * 4 + HASH_SIZE);

        // write f32 for fast read
        for (i, nums) in data.iter().enumerate() {
            let start = i * 3 * 4 + HASH_SIZE;
            LittleEndian::write_f32(&mut buffer[start..start + 4], nums[0] as f32);
            LittleEndian::write_f32(&mut buffer[start + 4..start + 8], nums[1] as f32);
            LittleEndian::write_f32(&mut buffer[start + 8..start + 12], nums[2] as f32);
        }

        // add hash
        let hash = XxHash3_128::oneshot(&buffer[HASH_SIZE..]);
        LittleEndian::write_u128(&mut buffer[..HASH_SIZE], hash);

        file.write_all(&buffer).unwrap();
        assert_eq!(buffer.len(), natoms * 3 * 4 + HASH_SIZE);
    }

    fn read_array_binary<T: R3Set>(path: PathBuf, dest: &mut T, buffer: &mut Vec<u8>) {
        let mut file =
            File::open(&path).expect(format!("failed to open file {}", path.display()).as_str());

        let natoms = dest.count();
        assert!(natoms > 0);
        assert_eq!(buffer.len(), natoms * 3 * 4 + HASH_SIZE);

        //buffer.clear();
        //file.read_to_end(buffer).unwrap();
        file.read_exact(buffer).unwrap();

        // check hash
        let hash: u128 = XxHash3_128::oneshot(&buffer[HASH_SIZE..]);
        let hash_read = LittleEndian::read_u128(&buffer[..HASH_SIZE]);
        if hash != hash_read {
            panic!("hash mismatch: {} != {}", hash, hash_read);
        }

        // read f32
        buffer[HASH_SIZE..]
            .chunks_exact(4 * 3)
            .enumerate()
            .for_each(|(i, chunk)| {
                let x = LittleEndian::read_f32(&chunk[0..4]);
                let y = LittleEndian::read_f32(&chunk[4..8]);
                let z = LittleEndian::read_f32(&chunk[8..12]);
                dest.set_value_x(i, x as f64);
                dest.set_value_y(i, y as f64);
                dest.set_value_z(i, z as f64);
            });
    }

    fn write_array_text<T: R3Set>(path: PathBuf, data: &T, buffer: &mut Vec<Vec<u8>>) {
        let file = File::create(&path)
            .expect(format!("failed to create file {}", path.display()).as_str());

        // parallelized for future
        let mut bw = BufWriter::new(file);
        for (i, nums) in data.iter().enumerate() {
            buffer[i].clear();
            writeln!(
                buffer[i],
                "{},{:.17e},{:.17e},{:.17e}",
                i, nums[0], nums[1], nums[2]
            )
            .unwrap();
            bw.write_all(&buffer[i]).unwrap();
        }
        bw.flush().unwrap();
    }

    fn read_array_text<T: R3Set>(path: PathBuf, dest: &mut T, buffer: &mut Vec<Vec<u8>>) {
        // read lines into Vec<Vec<u8>> buffer for parallelized processing (implemented in the future)
        match is_zstd_compressed(path) {
            FileState::Uncompressed(apath) => {
                let file = File::open(&apath)
                    .expect(format!("failed to open file {}", apath.display()).as_str());
                let br = BufReader::with_capacity(DEFAULT_BUFFER_CAPACITY, file);
                for (i, line) in br.lines().enumerate() {
                    buffer[i].clear();
                    buffer[i].write(line.unwrap().as_bytes()).unwrap();
                }
            }
            FileState::Compressed(apath) => {
                let file = File::open(&apath)
                    .expect(format!("failed to open file {}", apath.display()).as_str());
                let decompressed = zstd::decode_all(file).unwrap();
                for (i, line) in decompressed.lines().enumerate() {
                    let line = line.unwrap();
                    buffer[i].clear();
                    buffer[i].write(line.as_bytes()).unwrap();
                }
            }
            FileState::BothNotFound(apath) => {
                panic!(
                    "both compressed and uncompressed files not found. path: {}",
                    apath.display()
                );
            }
        };

        for line in buffer {
            let mut iter = std::str::from_utf8(line).unwrap().split(',');
            let i = iter.next().unwrap().parse::<usize>().unwrap();
            let x = iter.next().unwrap().parse::<f64>().unwrap();
            let y = iter.next().unwrap().parse::<f64>().unwrap();
            let z = iter.next().unwrap().parse::<f64>().unwrap();
            assert!(iter.next().is_none());
            dest.set_value_x(i, x);
            dest.set_value_y(i, y);
            dest.set_value_z(i, z);
        }
    }

    pub fn write_snapshot(&mut self, system: &PolymerSystem, frame: usize) {
        assert!(frame < self.nframes);
        assert_eq!(system.natoms(), self.probe.natoms());
        assert_eq!(system.has_velocity(), self.probe.has_velocity());
        assert_eq!(system.has_force(), self.probe.has_force());
        self.current_frame = frame;

        {
            // 既存トラジェクトリを上書きする場合はディレクトリ全体を初期化する仕様のため既存ファイルがあってはならない
            let path = match is_zstd_compressed(self.position_snapshot_path(frame)) {
                FileState::BothNotFound(path) => path,
                _ => unreachable!(),
            };
            match self.snapshot_type {
                SnapshotType::Binary => {
                    Self::write_array_binary(path, system.positions(), &mut self.buffer);
                }
                SnapshotType::Text => {
                    Self::write_array_text(path, system.positions(), &mut self.text_buffer);
                }
            }
        }

        if system.has_velocity() {
            let path = match is_zstd_compressed(self.velocity_snapshot_path(frame)) {
                FileState::BothNotFound(path) => path,
                _ => unreachable!(),
            };
            match self.snapshot_type {
                SnapshotType::Binary => {
                    Self::write_array_binary(path, system.velocities().unwrap(), &mut self.buffer);
                }
                SnapshotType::Text => {
                    Self::write_array_text(
                        path,
                        system.velocities().unwrap(),
                        &mut self.text_buffer,
                    );
                }
            }
        }

        if system.has_force() {
            let path = match is_zstd_compressed(self.force_snapshot_path(frame)) {
                FileState::BothNotFound(path) => path,
                _ => unreachable!(),
            };
            match self.snapshot_type {
                SnapshotType::Binary => {
                    Self::write_array_binary(path, system.forces().unwrap(), &mut self.buffer);
                }
                SnapshotType::Text => {
                    Self::write_array_text(path, system.forces().unwrap(), &mut self.text_buffer);
                }
            }
        }

        assert_eq!(self.current_frame, frame);
    }

    pub fn read_snapshot(&mut self, i: usize) {
        self.current_frame = i;
        assert!(i < self.nframes);

        {
            let path = self.position_snapshot_path(self.current_frame);
            match self.snapshot_type {
                SnapshotType::Binary => {
                    Self::read_array_binary(path, self.probe.positions_mut(), &mut self.buffer);
                }
                SnapshotType::Text => {
                    Self::read_array_text(path, self.probe.positions_mut(), &mut self.text_buffer);
                }
            }
        }

        if self.has_velocity {
            let path = self.velocity_snapshot_path(self.current_frame);
            let velocities = self.probe.velocities_mut().unwrap();
            match self.snapshot_type {
                SnapshotType::Binary => {
                    Self::read_array_binary(path, velocities, &mut self.buffer);
                }
                SnapshotType::Text => {
                    Self::read_array_text(path, velocities, &mut self.text_buffer);
                }
            }
        }

        if self.has_force {
            let path = self.force_snapshot_path(self.current_frame);
            let forces = self.probe.forces_mut().unwrap();
            match self.snapshot_type {
                SnapshotType::Binary => {
                    Self::read_array_binary(path, forces, &mut self.buffer);
                }
                SnapshotType::Text => {
                    Self::read_array_text(path, forces, &mut self.text_buffer);
                }
            }
        }

        self.is_initiated = true;
    }

    pub fn replicate(&self, snapshot_type: SnapshotType, src: PathBuf, dst: PathBuf) {
        assert!(src.exists());
        assert!(src != dst);

        let mut traj = Trajectory::from_file(src);
        let nframes = traj.nframes;
        traj.read_snapshot(0);

        let mut traj_new =
            Trajectory::create(dst, traj.probe().unwrap().clone(), nframes, snapshot_type);
        assert_eq!(traj_new.current_frame, 0);
        assert!(!traj_new.is_initiated);

        for i in 0..nframes {
            traj.read_snapshot(i);
            assert_eq!(traj.current_frame, i);
            traj_new.write_snapshot(traj.probe_mut().unwrap(), i);
            assert!(!traj_new.is_initiated);
            println!("write snapshot {}", i);
        }

        std::mem::swap(&mut traj_new.times, &mut traj.times);
        std::mem::swap(&mut traj_new.timesteps, &mut traj.timesteps);
        std::mem::swap(&mut traj_new.bounding_boxes, &mut traj.bounding_boxes);
        traj_new.save();
    }
}

#[cfg(test)]
mod test {
    use super::*;

    fn read_checked(name: &str, nframes: usize, stype: SnapshotType) -> Trajectory {
        let root = PathBuf::from(name);
        let traj = Trajectory::from_file(root);
        assert_eq!(traj.nframes, nframes);
        assert_eq!(traj.times.len(), nframes);
        assert_eq!(traj.timesteps.len(), nframes);
        assert_eq!(traj.bounding_boxes.len(), nframes);
        assert_eq!(traj.current_frame, 0);
        assert_eq!(traj.snapshot_type, stype);

        traj
    }

    #[test]
    fn test_from_text_file() {
        for i in 1..=3 {
            let root = PathBuf::from(format!("test/test_trajectory_{}", i).as_str());
            let nframes = 100;

            let traj = Trajectory::from_file(root);
            assert_eq!(traj.nframes, nframes);
            assert_eq!(traj.times.len(), nframes);
            assert_eq!(traj.timesteps.len(), nframes);
            assert_eq!(traj.bounding_boxes.len(), nframes);
            assert_eq!(traj.current_frame, 0);
            assert_eq!(traj.snapshot_type, SnapshotType::Text);
        }
    }

    #[test]
    fn test_text_text_equality() {
        //let name = format!("test/test_trajectory_{}", 0);
        //let nframes = 100;
        //let traj = read_checked(name.as_str(), nframes, SnapshotType::Text);

        //let dst = "";
        //let mut traj_new =
        //    Trajectory::create(dst, traj.probe().unwrap().clone(), nframes, snapshot_type);
        //assert_eq!(traj_new.current_frame, 0);
        //assert!(!traj_new.is_initiated);
    }

    #[test]
    fn test_conv_text_to_binary() {
        for i in 1..=3 {
            let root = PathBuf::from(format!("test/test_trajectory_{}", i).as_str());
            let traj = Trajectory::from_file(root.clone());
            let nframes = 100;
            assert_eq!(traj.nframes, nframes);
            assert_eq!(traj.times.len(), nframes);
            assert_eq!(traj.timesteps.len(), nframes);
            assert_eq!(traj.bounding_boxes.len(), nframes);
            assert_eq!(traj.current_frame, 0);
            assert_eq!(traj.snapshot_type, SnapshotType::Text);

            let name = PathBuf::from(format!("test/converted_test_trajectory_{}", i).as_str());
            traj.replicate(SnapshotType::Binary, root.clone(), name.clone());
        }
    }

    #[test]
    fn test_from_binary_file() {
        for i in 1..=3 {
            let root = PathBuf::from(format!("test/converted_test_trajectory_{}", i).as_str());
            let nframes = 100;

            let traj = Trajectory::from_file(root);
            assert_eq!(traj.nframes, nframes);
            assert_eq!(traj.times.len(), nframes);
            assert_eq!(traj.timesteps.len(), nframes);
            assert_eq!(traj.bounding_boxes.len(), nframes);
            assert_eq!(traj.current_frame, 0);
            assert_eq!(traj.snapshot_type, SnapshotType::Binary);
        }
    }

    #[test]
    fn test_conv_binary_to_text() {
        for i in 1..=3 {
            let root = PathBuf::from(format!("test/converted_test_trajectory_{}", i).as_str());
            let traj = Trajectory::from_file(root.clone());
            let nframes = 100;
            assert_eq!(traj.nframes, nframes);
            assert_eq!(traj.times.len(), nframes);
            assert_eq!(traj.timesteps.len(), nframes);
            assert_eq!(traj.bounding_boxes.len(), nframes);
            assert_eq!(traj.current_frame, 0);
            assert_eq!(traj.snapshot_type, SnapshotType::Binary);

            let name = PathBuf::from(format!("test/converted2_test_trajectory_{}", i).as_str());
            traj.replicate(SnapshotType::Text, root.clone(), name.clone());
        }
    }
}

use std::ffi::OsStr;
use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Read, Write};
use std::ops::Index;
use std::path::PathBuf;
use std::process::exit;

use itertools::sorted_unstable;
use nalgebra::{Const, DMatrix, DVector, Dyn, MatrixView, Point3, Vector1, Vector3};
use rustc_hash::FxHashMap;

use crate::DefaultIdx;
use crate::polymer_system::*;
use crate::polymer_system_builder::*;
use crate::trajectory::*;
use crate::types::{
    bounding_box::BoundingBox,
    label_util::{NameEncoder, StructureKind, SubStructure},
    util::{AtomProperty, Bond},
    vector_3d_data::{Forces, R3Set, Velocities},
};

//trait PropertyTrait: Default + Sized + Index<usize, Output = f64> {}
trait PropertyTrait: Default + Sized {}

// Vector1, Vector3, Point3の時系列はMatrixにできるが動径分布の時系列はMatrixにできないため、
//Matrixの代わりにtraitを定義する
impl PropertyTrait for f64 {}
impl PropertyTrait for Vector3<f64> {}
impl PropertyTrait for Point3<f64> {}
impl PropertyTrait for DVector<f64> {} // 動径分布関数に用いるためframeごとに可変長の必要あり

#[derive(Debug, Clone)]
pub struct TimeSeries<T: PropertyTrait> {
    name: String,
    frames: Vec<usize>,
    data: Vec<T>,
}
impl<T: PropertyTrait> TimeSeries<T> {
    pub fn new(name: String) -> Self {
        Self {
            name,
            frames: Vec::new(),
            data: Vec::new(),
        }
    }

    pub fn name(&self) -> &str {
        self.name.as_str()
    }

    pub fn data(&self) -> &Vec<T> {
        &self.data
    }

    pub fn data_moved(self) -> Vec<T> {
        self.data
    }

    pub fn at_frame(&self, frame: usize) -> &T {
        &self.data[frame]
    }

    pub fn frames(&self) -> &[usize] {
        &self.frames
    }

    fn add_frame(&mut self, frame: usize, data: T) {
        self.frames.push(frame);
        self.data.push(data);
    }
}

#[derive(Debug, Clone)]
pub struct StructureTimeSeries<T: PropertyTrait> {
    name: String,
    frames: Vec<usize>,
    structures: Vec<SubStructure>,
    data: Vec<Vec<T>>, // data[structure][frame]
}

impl<T: PropertyTrait> StructureTimeSeries<T> {
    pub fn new(name: String) -> Self {
        Self {
            name,
            frames: Vec::new(),
            structures: Vec::new(),
            data: Vec::new(),
        }
    }

    pub fn name(&self) -> &str {
        &self.name.as_str()
    }

    pub fn data(&self) -> &Vec<Vec<T>> {
        &self.data
    }

    pub fn data_moved(self) -> Vec<Vec<T>> {
        self.data
    }

    pub fn time_slice(&self, frame: usize) -> impl Iterator<Item = &T> {
        self.data.iter().map(move |v| &v[frame])
    }

    pub fn structure_slice(&self, label: &SubStructure) -> &Vec<T> {
        let idx = self
            .structures
            .iter()
            .position(|structure| structure == label)
            .expect("Structure not found");
        &self.data[idx]
    }

    pub fn structure_slice_by_idx(&self, label_idx: crate::DefaultIdx) -> &Vec<T> {
        let idx = self
            .structures
            .iter()
            .position(|structure| structure.index() == label_idx)
            .expect("Structure not found");
        &self.data[idx]
    }

    pub fn frames(&self) -> &[usize] {
        &self.frames
    }

    pub fn structures(&self) -> &[SubStructure] {
        &self.structures
    }

    fn add_frame(&mut self, frame: usize, structure_idx: usize, data: T) {
        // structureはscan開始時に追加
        self.frames.push(frame);
        self.data[structure_idx].push(data);
    }
}

pub(crate) struct TrajectoryScanner<'a> {
    traj: &'a mut Trajectory,

    filters: Vec<fn(&PolymerSystem) -> bool>,

    // functions to calculate properties within each snapshot
    scalar_functions: FxHashMap<String, fn(&PolymerSystem) -> f64>,
    point3_functions: FxHashMap<String, fn(&PolymerSystem) -> Point3<f64>>,
    vector3_functions: FxHashMap<String, fn(&PolymerSystem) -> Vector3<f64>>,
    dvec_functions: FxHashMap<String, fn(&PolymerSystem) -> DVector<f64>>,

    scalar_results: FxHashMap<String, TimeSeries<f64>>,
    point3_results: FxHashMap<String, TimeSeries<Point3<f64>>>,
    vector3_results: FxHashMap<String, TimeSeries<Vector3<f64>>>,
    dvec_results: FxHashMap<String, TimeSeries<DVector<f64>>>,

    // functions to calculate properties corresponding to substructures within each snapshot
    scalar_structure_functions: FxHashMap<String, fn(&PolymerSystem, &SubStructure) -> f64>,
    point3_structure_functions: FxHashMap<String, fn(&PolymerSystem, &SubStructure) -> Point3<f64>>,
    vector3_structure_functions:
        FxHashMap<String, fn(&PolymerSystem, &SubStructure) -> Vector3<f64>>,

    scalar_structure_results: FxHashMap<String, StructureTimeSeries<f64>>,
    point3_structure_results: FxHashMap<String, StructureTimeSeries<Point3<f64>>>,
    vector3_structure_results: FxHashMap<String, StructureTimeSeries<Vector3<f64>>>,
}

impl<'a> TrajectoryScanner<'a> {
    pub fn scan(mut self) -> Self {
        let nframes = self.traj.nframes();
        for frame in 0..nframes {
            self.traj.read_snapshot(frame);
            if self
                .filters
                .iter()
                .any(|func| func(self.traj.probe().unwrap()))
            {
                continue;
            }
            let snapshot = self.traj.probe().unwrap();

            // scalar functions
            for (name, func) in &self.scalar_functions {
                self.scalar_results
                    .get_mut(name)
                    .unwrap()
                    .add_frame(frame, func(snapshot));
            }

            // point3 functions
            for (name, func) in &self.point3_functions {
                self.point3_results
                    .get_mut(name)
                    .unwrap()
                    .add_frame(frame, func(snapshot));
            }

            // vector3 functions
            for (name, func) in &self.vector3_functions {
                self.vector3_results
                    .get_mut(name)
                    .unwrap()
                    .add_frame(frame, func(snapshot));
            }

            // dvec functions
            for (name, func) in &self.dvec_functions {
                self.dvec_results
                    .get_mut(name)
                    .unwrap()
                    .add_frame(frame, func(snapshot));
            }

            // scalar structure functions
            for (name, func) in &self.scalar_structure_functions {
                let result = self.scalar_structure_results.get_mut(name).unwrap();
                let n = result.structures().len();
                for str_idx in 0..n {
                    let structure = &result.structures()[str_idx];
                    result.add_frame(frame, str_idx, func(snapshot, structure));
                }
            }

            // point3 structure functions
            for (name, func) in &self.point3_structure_functions {
                let result = self.point3_structure_results.get_mut(name).unwrap();
                let n = result.structures().len();
                for str_idx in 0..n {
                    let structure = &result.structures()[str_idx];
                    result.add_frame(frame, str_idx, func(snapshot, structure));
                }
            }

            // vector3 structure functions
            for (name, func) in &self.vector3_structure_functions {
                let result = self.vector3_structure_results.get_mut(name).unwrap();
                let n = result.structures().len();
                for str_idx in 0..n {
                    let structure = &result.structures()[str_idx];
                    result.add_frame(frame, str_idx, func(snapshot, structure));
                }
            }
        }

        self
    }

    pub fn filter(mut self, filter: fn(&PolymerSystem) -> bool) -> Self {
        self.filters.push(filter);
        self
    }

    pub fn set_fn_scalar(mut self, name: String, func: fn(&PolymerSystem) -> f64) -> Self {
        if self.scalar_functions.contains_key(&name) {
            panic!("Function with name {} already exists", name);
        }
        assert!(!self.scalar_results.contains_key(&name));
        self.scalar_functions.insert(name.clone(), func);
        self.scalar_results
            .insert(name.clone(), TimeSeries::new(name));
        self
    }

    pub fn set_fn_point3(mut self, name: String, func: fn(&PolymerSystem) -> Point3<f64>) -> Self {
        if self.point3_functions.contains_key(&name) {
            panic!("Function with name {} already exists", name);
        }
        self.point3_functions.insert(name.clone(), func);
        self.point3_results
            .insert(name.clone(), TimeSeries::new(name));
        self
    }

    pub fn set_fn_vector3(
        mut self,
        name: String,
        func: fn(&PolymerSystem) -> Vector3<f64>,
    ) -> Self {
        if self.vector3_functions.contains_key(&name) {
            panic!("Function with name {} already exists", name);
        }
        self.vector3_functions.insert(name.clone(), func);
        self.vector3_results
            .insert(name.clone(), TimeSeries::new(name));
        self
    }

    pub fn set_fn_dvec(mut self, name: String, func: fn(&PolymerSystem) -> DVector<f64>) -> Self {
        if self.dvec_functions.contains_key(&name) {
            panic!("Function with name {} already exists", name);
        }
        self.dvec_functions.insert(name.clone(), func);
        self.dvec_results
            .insert(name.clone(), TimeSeries::new(name));
        self
    }

    pub fn set_fn_scalar_structure(
        mut self,
        name: String,
        structures: Vec<SubStructure>,
        func: fn(&PolymerSystem, &SubStructure) -> f64,
    ) -> Self {
        if self.scalar_structure_functions.contains_key(&name) {
            panic!("Function with name {} already exists", name);
        }
        assert!(!self.scalar_structure_results.contains_key(&name));

        self.scalar_structure_functions.insert(name.clone(), func);

        let mut sts = StructureTimeSeries::<f64>::new(name.clone());
        sts.structures = structures;
        self.scalar_structure_results.insert(name.clone(), sts);
        self
    }

    pub fn set_fn_point3_structure(
        mut self,
        name: String,
        structures: Vec<SubStructure>,
        func: fn(&PolymerSystem, &SubStructure) -> Point3<f64>,
    ) -> Self {
        if self.point3_structure_functions.contains_key(&name) {
            panic!("Function with name {} already exists", name);
        }

        self.point3_structure_functions.insert(name.clone(), func);

        let mut sts = StructureTimeSeries::<Point3<f64>>::new(name.clone());
        sts.structures = structures;
        self.point3_structure_results.insert(name.clone(), sts);
        self
    }

    pub fn set_fn_vector3_structure(
        mut self,
        name: String,
        structures: Vec<SubStructure>,
        func: fn(&PolymerSystem, &SubStructure) -> Vector3<f64>,
    ) -> Self {
        if self.vector3_structure_functions.contains_key(&name) {
            panic!("Function with name {} already exists", name);
        }

        self.vector3_structure_functions.insert(name.clone(), func);

        let mut sts = StructureTimeSeries::<Vector3<f64>>::new(name.clone());
        sts.structures = structures;
        self.vector3_structure_results.insert(name.clone(), sts);
        self
    }

    pub fn get_scalar(&self, name: &str) -> &TimeSeries<f64> {
        match self.scalar_results.get(name) {
            Some(result) => result,
            None => panic!("No scalar result found with name {}", name),
        }
    }

    pub fn get_point3(&self, name: &str) -> &TimeSeries<Point3<f64>> {
        match self.point3_results.get(name) {
            Some(result) => result,
            None => panic!("No point3 result found with name {}", name),
        }
    }

    pub fn get_vector3(&self, name: &str) -> &TimeSeries<Vector3<f64>> {
        match self.vector3_results.get(name) {
            Some(result) => result,
            None => panic!("No vector3 result found with name {}", name),
        }
    }

    pub fn get_dvec(&self, name: &str) -> &TimeSeries<DVector<f64>> {
        match self.dvec_results.get(name) {
            Some(result) => result,
            None => panic!("No dvec result found with name {}", name),
        }
    }

    pub fn get_scalar_structure(&self, name: &str) -> &StructureTimeSeries<f64> {
        match self.scalar_structure_results.get(name) {
            Some(result) => result,
            None => panic!("No scalar structure result found with name {}", name),
        }
    }

    pub fn get_point3_structure(&self, name: &str) -> &StructureTimeSeries<Point3<f64>> {
        match self.point3_structure_results.get(name) {
            Some(result) => result,
            None => panic!("No point3 structure result found with name {}", name),
        }
    }

    pub fn get_vector3_structure(&self, name: &str) -> &StructureTimeSeries<Vector3<f64>> {
        match self.vector3_structure_results.get(name) {
            Some(result) => result,
            None => panic!("No vector3 structure result found with name {}", name),
        }
    }
}

impl Trajectory {
    pub fn scanner(&mut self) -> TrajectoryScanner {
        TrajectoryScanner {
            traj: self,
            filters: Vec::new(),
            scalar_functions: FxHashMap::default(),
            point3_functions: FxHashMap::default(),
            vector3_functions: FxHashMap::default(),
            dvec_functions: FxHashMap::default(),
            scalar_results: FxHashMap::default(),
            point3_results: FxHashMap::default(),
            vector3_results: FxHashMap::default(),
            dvec_results: FxHashMap::default(),
            scalar_structure_functions: FxHashMap::default(),
            point3_structure_functions: FxHashMap::default(),
            vector3_structure_functions: FxHashMap::default(),
            scalar_structure_results: FxHashMap::default(),
            point3_structure_results: FxHashMap::default(),
            vector3_structure_results: FxHashMap::default(),
        }
    }
}

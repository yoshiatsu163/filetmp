//use crate::label_util::IndexedLabel;
use crate::polymer_system;
//use crate::vector3D_data::R3PropCollection;
use std::io::{BufRead, BufReader, Read, Write};
use std::path::Path;
//use nalgebra::Vector3;

fn writeln(bufwriter: &mut std::io::BufWriter<std::fs::File>, line: &str) {
    bufwriter.write(line.as_bytes()).unwrap();
    bufwriter.write("\n".as_bytes()).unwrap();
}

fn write_inline(bufwriter: &mut std::io::BufWriter<std::fs::File>, line: &str) {
    bufwriter.write(line.as_bytes()).unwrap();
}

fn print_label_polymer<Mode>(system: &polymer_system::PolymerSystem<Mode>, atom: &polymer_system::Atom) -> (String, String) {
    match atom.polymer_chain() {
        Some(label) => {
            let (name, idx) = system.substructure_info(label);
            (name, idx.to_string())
        },
        None => ("-".to_string(), "-".to_string()),
    }
}

fn print_label_monomer<Mode>(system: &polymer_system::PolymerSystem<Mode>, atom: &polymer_system::Atom) -> (String, String) {
    match atom.monomer() {
        Some(label) => {
            let (name, idx) = system.substructure_info(label);
            (name, idx.to_string())
        },
        None => ("-".to_string(), "-".to_string()),
    }
}

fn print_label_crosslink<Mode>(system: &polymer_system::PolymerSystem<Mode>, atom: &polymer_system::Atom) -> (String, String) {
    match atom.crosslink() {
        Some(label) => {
            let (name, idx) = system.substructure_info(label);
            (name, idx.to_string())
        },
        None => ("-".to_string(), "-".to_string()),
    }
}

pub fn write_hmd_text<T: AsRef<Path>, Finalized>(path: T, system: &polymer_system::PolymerSystem<Finalized>) {
    let file = match std::fs::File::create(path) {
        Ok(f) => f,
        Err(e) => panic!("{}", e),
    };
    let mut br = std::io::BufWriter::new(file);

    // header
    writeln(&mut br, "# this file is written by HMD-rs v 0.1.0");
    writeln(&mut br, "# non-ascii character is prohibited other than comment line that begins with #");
    writeln(&mut br, "# NEVER ADD COMMENT at the end of the data line");
    writeln(&mut br, "# ");
    writeln(&mut br, "# file format is:");
    writeln(&mut br, "# {{");
    writeln(&mut br, "#     bond list of the topology sorted by bond index (↓ each column definition)");
    writeln(&mut br, "#     head_atom_index tail_atom_index bond_order_numerator/bond_order_denominator");
    writeln(&mut br, "# }}");
    writeln(&mut br, "# {{");
    writeln(&mut br, "#     structure label list sorted by atom index");
    writeln(&mut br, "#     if the atom is not belong to any polymer chain, monomer, or crosslink, the label is set to '-'");
    writeln(&mut br, "#      (↓ each column definition)");
    writeln(&mut br, "#     chain_name chain_index monomer_name monomer_index crosslink_name crosslink_index is_branch_point is_main_chain is_main_terminal");
    writeln(&mut br, "# }}");
    writeln(&mut br, "# {{");
    writeln(&mut br, "#     snapshot section (repeated for each snapshot)");
    writeln(&mut br, "#     1st line: timestep: <timestep>");
    writeln(&mut br, "#     2nd line: time: <time>");
    writeln(&mut br, "#     3-5 line: box vector coordinates in the order of a, b, c");
    writeln(&mut br, "#     after 5th line: atom position, velocity, and force in the order of x, y, z, vx, vy, vz, fx, fy, fz");
    writeln(&mut br, "#     if velocity and force are empty, its values are printed as '-'");
    writeln(&mut br, "# }}");


    // topology
    let topo = system.topology();
    writeln!(&mut br, "{{ # topology");
    for bond_id in topo.edge_indices() {
        let Some((head, tail)) = topo.edge_endpoints(bond_id) else {
            panic!("edge not found");
        };
        let bond_order = topo.edge_weight(bond_id).unwrap();

        writeln(&mut br, format!(
            "    {} {} {}/{}",
            head.index(),
            tail.index(),
            bond_order.numer(),
            bond_order.denom()
        ).as_str());
    }
    writeln(&mut br, "}}");


    // structure label
    writeln(&mut br, "{{ # structure labels");
    for atom_id in topo.node_indices() {
        let atom = topo.node_weight(atom_id).unwrap();
        
        let (chain_name, chain_idx) = print_label_polymer(system, atom);
        let (monomer_name, monomer_idx) = print_label_monomer(system, atom);
        let (crosslink_name, crosslink_idx) = print_label_crosslink(system, atom);

        writeln(&mut br, format!(
            "{} {} {} {} {} {} {} {} {}\n",
            chain_name,
            chain_idx,
            monomer_name,
            monomer_idx,
            crosslink_name,
            crosslink_idx,
            if atom.is_branch_point() {"1"} else {"0"},
            if atom.is_main_chain() {"1"} else {"0"},
            if atom.is_main_terminal() {"1"} else {"0"},
        ).as_str());
    }
    writeln(&mut br, "}}");

    _add_snapshot(&mut br, system);

    match br.flush() {
        Ok(()) => (),
        Err(e) => panic!("failed to write to file: {}", e),
    }
}

fn add_snapshot<T: AsRef<Path>, Finalized>(path: T, system: &polymer_system::PolymerSystem<Finalized>) {
    let file = match std::fs::File::create(path) {
        Ok(f) => f,
        Err(e) => panic!("{}", e),
    };
    let mut br = std::io::BufWriter::new(file);

    _add_snapshot(&mut br, system);
}

fn _add_snapshot<Finalized>(mut br: &mut std::io::BufWriter<std::fs::File>, system: &polymer_system::PolymerSystem<Finalized>) {
    writeln(&mut br, "{{ # each snapshot");

    // timestep
    writeln(&mut br, format!("timestep: {}", system.timestep()).as_str());
    
    // time
    writeln(&mut br, format!("time: {}", system.time()).as_str());

    // box coordinates

    writeln(&mut br, format!(
        "{} {} {}",
        system.bbox().avec().x as f32,
        system.bbox().avec().y as f32,
        system.bbox().avec().z as f32,
    ).as_str());
    writeln(&mut br, format!(
        "{} {} {}",
        system.bbox().bvec().x as f32,
        system.bbox().bvec().y as f32,
        system.bbox().bvec().z as f32,
    ).as_str());
    writeln(&mut br, format!(
        "{} {} {}",
        system.bbox().cvec().x as f32,
        system.bbox().cvec().y as f32,
        system.bbox().cvec().z as f32,
    ).as_str());

    // atom coordinates

    for atom_id in system.topology().node_indices() {
        let atom = system.topology().node_weight(atom_id).unwrap();
        let pos = atom.position();
        let v = atom.velocity();
        let f = atom.force();

        writeln(&mut br, format!(
            "{} {} {} {} {} {} {} {} {}",
            pos.x as f32,
            pos.y as f32,
            pos.z as f32,
            if v.is_some() {(v.unwrap().x as f32).to_string()} else {"-".to_string()},
            if v.is_some() {(v.unwrap().y as f32).to_string()} else {"-".to_string()},
            if v.is_some() {(v.unwrap().z as f32).to_string()} else {"-".to_string()},
            if f.is_some() {(f.unwrap().x as f32).to_string()} else {"-".to_string()},
            if f.is_some() {(f.unwrap().y as f32).to_string()} else {"-".to_string()},
            if f.is_some() {(f.unwrap().z as f32).to_string()} else {"-".to_string()},
        ).as_str());
    }
}
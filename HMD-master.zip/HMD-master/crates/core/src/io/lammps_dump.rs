use crate::polymer_system;
use std::io::{BufRead, BufReader, Read};
use std::path::Path;
use nalgebra::Vector3;

// trajectoryの仕様が決まってからでないとredaを作れない
pub fn read_lammps_dump<P: AsRef<Path>>(path: P) -> polymer_system::PolymerSystem {
    //let path_ref: &Path = path.as_ref();
    let Ok(file) = std::fs::File::open(path) else {
        panic!("failed to open file: {:?}", path.as_ref());
    };

    let mut lines = BufReader::new(file).lines();
    let mut system = polymer_system::PolymerSystem::new();

    // header section
    while let Some(Ok(line)) = lines.next() {
        let tokens = line.split_whitespace().collect::<Vec<&str>>();
        match tokens[..] {
            ["ITEM:", "TIMESTEP"] => {
                let timestep = lines.next().unwrap().unwrap();
                let timestep: u64 = timestep.trim().parse::<u64>().unwrap();
                todo!();
            },
            ["ITEM:", "NUMBER", "OF", "ATOMS"] => {
                let natoms = lines.next().unwrap().unwrap();
                let natoms: usize = natoms.trim().parse::<usize>().unwrap();
                todo!();
            },
            ["ITEM:", "BOX", "BOUNDS", x, y, z] => {
                if x != "pp" || y != "pp" || z != "pp" {
                    panic!("unsupported box style: {} {} {}", x, y, z);
                } else {
                    read_boxinfo(&mut system, &mut lines);
                    break;
                }
            },
            _ => (),
        }
    }

    // parse atom section columns
    let line = lines.next().unwrap().unwrap();
    let tokens = line.split_whitespace().collect::<Vec<&str>>();
    if tokens[0] != "ITEM:" || tokens[1] != "ATOMS" {
        panic!("expected ATOMS section");
    }
    let id_col = tokens.iter().position(|&s| s == "id");
    let mol_col = tokens.iter().position(|&s| s == "type");
    todo!();

    // atom section
    while let Some(Ok(line)) = lines.next() {
        if line.starts_with("ITEM") {
            panic!("currently multi snapshot file is not supported");
        }

        let tokens = line.split_whitespace();
    }

    system
}

fn read_boxinfo(system: &mut polymer_system::PolymerSystem, lines: &mut std::io::Lines<BufReader<std::fs::File>>) {
    let line = lines.next().unwrap().unwrap();
    let tokens = line.split_whitespace().collect::<Vec<&str>>();
    let xlo = tokens[0].parse::<f64>().unwrap();
    let xhi = tokens[1].parse::<f64>().unwrap();

    let line = lines.next().unwrap().unwrap();
    let tokens = line.split_whitespace().collect::<Vec<&str>>();
    let ylo = tokens[2].parse::<f64>().unwrap();
    let yhi = tokens[3].parse::<f64>().unwrap();

    let line = lines.next().unwrap().unwrap();
    let tokens = line.split_whitespace().collect::<Vec<&str>>();
    let zlo = tokens[4].parse::<f64>().unwrap();
    let zhi = tokens[5].parse::<f64>().unwrap();

    system.bbox_mut().set_avec(Vector3::new(xhi - xlo, 0.0, 0.0));
    system.bbox_mut().set_bvec(Vector3::new(0.0, yhi - ylo, 0.0));
    system.bbox_mut().set_cvec(Vector3::new(0.0, 0.0, zhi - zlo));
}
